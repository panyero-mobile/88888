import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BottomNavigation } from '@/components/bottom-navigation'

const Layout = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center">
          <Link href="/">
            <Image
              src="https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/exchange-crypto-app-template-u-i-kit-mj3gm6/assets/d8drx68l5tq1/Untitled_design.png"
              alt="Panyero Logo"
              width={120}
              height={50}
              objectFit="contain"
            />
          </Link>
          <Link href="/more">
            <Avatar className="w-10 h-10 cursor-pointer">
              <AvatarImage src="/placeholder-user.jpg" alt="User" />
              <AvatarFallback>UN</AvatarFallback>
            </Avatar>
          </Link>
        </div>
      </header>
      <main className="flex-1 pt-4 pb-20">
        <div className="container mx-auto px-4">
          {children}
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
};

export default Layout;

