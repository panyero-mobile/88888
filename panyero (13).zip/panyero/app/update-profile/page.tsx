import { Metadata } from 'next'
import { UpdateProfileForm } from '@/components/update-profile-form'

export const metadata: Metadata = {
  title: 'Panyero - Update Profile',
  description: 'Update your profile information and add facial recognition',
}

export default function UpdateProfilePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Update Profile</h1>
        <UpdateProfileForm />
      </div>
    </main>
  )
}

