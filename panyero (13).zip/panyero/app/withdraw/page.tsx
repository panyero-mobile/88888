import { Metadata } from 'next'
import { WithdrawContent } from '@/components/withdraw-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Withdraw',
  description: 'Withdraw funds from your Panyero account',
}

export default function WithdrawPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Withdraw</h1>
        <WithdrawContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

