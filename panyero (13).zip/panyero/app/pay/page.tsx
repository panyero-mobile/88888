'use client'

import { useState } from 'react'
import { QRCodeScanner } from '@/components/qr-code-scanner'
import { QRCodeGenerator } from '@/components/qr-code-generator'
import { PaymentProcessor } from '@/components/payment-processor'
import { ManualAccountEntry } from '@/components/manual-account-entry'
import { BottomNavigation } from '@/components/bottom-navigation'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PayPage() {
  const [scannedAccount, setScannedAccount] = useState<string | null>(null)
  const [manualAccount, setManualAccount] = useState<{
    accountNumber: string;
    name: string;
    amount: number;
    message: string;
  } | null>(null)
  const userBalance = 1000 // This would typically come from a user context or API
  const userAccountNumber = '1234567890' // This would typically come from a user context or API

  const handleValidScan = (accountNumber: string) => {
    setScannedAccount(accountNumber)
    setManualAccount(null)
  }

  const handleValidManualEntry = (accountNumber: string, name: string, amount: number, message: string) => {
    setManualAccount({ accountNumber, name, amount, message })
    setScannedAccount(null)
  }

  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Pay</h1>
        <Tabs defaultValue="scan" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="scan">Scan QR</TabsTrigger>
            <TabsTrigger value="generate">Your QR</TabsTrigger>
          </TabsList>
          <TabsContent value="scan" className="pt-4 space-y-4">
            {!scannedAccount && !manualAccount ? (
              <>
                <QRCodeScanner onValidScan={handleValidScan} />
                <ManualAccountEntry onValidAccount={handleValidManualEntry} />
              </>
            ) : (
              <PaymentProcessor 
                accountNumber={scannedAccount || manualAccount?.accountNumber || ''}
                recipientName={manualAccount?.name}
                amount={manualAccount?.amount}
                message={manualAccount?.message}
                userBalance={userBalance}
              />
            )}
          </TabsContent>
          <TabsContent value="generate">
            <QRCodeGenerator accountNumber={userAccountNumber} />
          </TabsContent>
        </Tabs>
      </div>
      <BottomNavigation />
    </main>
  )
}

