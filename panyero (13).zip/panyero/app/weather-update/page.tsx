import { Metadata } from 'next'
import { WeatherForecast } from '@/components/weather-forecast'

export const metadata: Metadata = {
  title: 'Panyero - Weather Forecast',
  description: 'Get detailed weather forecasts for your area',
}

export default function WeatherUpdatePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Weather Forecast</h1>
        <WeatherForecast />
      </div>
    </main>
  )
}

