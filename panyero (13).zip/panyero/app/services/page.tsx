import { Metadata } from 'next'
import { ServicesGrid } from '@/components/services/services-grid'
import { GamesSection } from '@/components/games-section'
import { AIPersonaSection } from '@/components/ai-persona-section'

export const metadata: Metadata = {
  title: 'Panyero - Services',
  description: 'Access all Panyero services, including games and AI personas',
}

export default function ServicesPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-6 p-4 pt-6">
        <h1 className="text-2xl font-bold">Services</h1>
        <ServicesGrid />
        <h2 className="text-xl font-semibold mt-8">Games</h2>
        <GamesSection />
        <h2 className="text-xl font-semibold mt-8">AI Persona</h2>
        <AIPersonaSection />
      </div>
    </main>
  )
}

