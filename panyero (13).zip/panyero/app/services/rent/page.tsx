import { Metadata } from 'next'
import { RentBillServiceContent } from '@/components/services/rent-bill-service-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Rent Bill Service',
  description: 'Manage and pay your rent bills',
}

export default function RentBillServicePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Rent Bill Service</h1>
        <RentBillServiceContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

