import { Metadata } from 'next'
import { GamesServiceContent } from '@/components/services/games-service-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Games Service',
  description: 'Play games and manage your gaming credits',
}

export default function GamesServicePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Games Service</h1>
        <GamesServiceContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

