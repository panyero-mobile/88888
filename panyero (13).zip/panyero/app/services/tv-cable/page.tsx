import { Metadata } from 'next'
import { TVCableServiceContent } from '@/components/services/tv-cable-service-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - TV Cable Service',
  description: 'Manage your TV cable service subscriptions and payments',
}

export default function TVCableServicePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">TV Cable Service</h1>
        <TVCableServiceContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

