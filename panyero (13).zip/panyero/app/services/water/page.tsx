import { Metadata } from 'next'
import { WaterServiceContent } from '@/components/services/water-service-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Water Service',
  description: 'Manage your water service payments and usage',
}

export default function WaterServicePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Water Service</h1>
        <WaterServiceContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

