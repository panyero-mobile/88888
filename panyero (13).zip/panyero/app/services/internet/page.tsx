import { Metadata } from 'next'
import { InternetServiceContent } from '@/components/services/internet-service-content'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Internet Service',
  description: 'Manage your internet service payments and subscriptions',
}

export default function InternetServicePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Internet Service</h1>
        <InternetServiceContent />
      </div>
      <BottomNavigation />
    </main>
  )
}

