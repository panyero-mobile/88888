import { Metadata } from 'next'
import { LotteryInterface } from '@/components/services/lottery-interface'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Lottery',
  description: 'Play Philippine Charity Sweepstakes lottery games',
}

export default function LotteryPage() {
  return (
    <main className="flex min-h-screen flex-col bg-[#4834d4]">
      <div className="flex-1">
        <LotteryInterface />
      </div>
      <BottomNavigation />
    </main>
  )
}

