import { Metadata } from 'next'
import { WalletBalance } from '@/components/wallet-balance'
import { QuickActions } from '@/components/quick-actions'
import { ServicesGrid } from '@/components/services-grid'
import { ChatInterface } from '@/components/chat-interface'
import { UserScroll } from '@/components/user-scroll'
import { PromoBanner } from '@/components/promo-banner'
import { RecentTransaction } from '@/components/recent-transaction'
import { WeatherUpdate } from '@/components/weather-update'
import { RouteCheck } from '@/components/route-check'

export const metadata: Metadata = {
  title: 'Panyero - Home',
  description: 'Your all-in-one financial and lifestyle app',
}

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4">
        <WalletBalance />
        <QuickActions />
        <ServicesGrid />
        <ChatInterface />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <WeatherUpdate />
          <RouteCheck />
        </div>
        <UserScroll />
        <PromoBanner />
        <RecentTransaction />
      </div>
    </main>
  )
}

