import { Metadata } from 'next'
import { ProfileSection } from '@/components/profile-section'
import { SettingsList } from '@/components/settings-list'
import { SupportSection } from '@/components/support-section'
import { AccountSecurity } from '@/components/account-security'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - More',
  description: 'Access more features and settings',
}

export default function MorePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <ProfileSection />
        <AccountSecurity />
        <SettingsList />
        <SupportSection />
      </div>
      <BottomNavigation />
    </main>
  )
}

