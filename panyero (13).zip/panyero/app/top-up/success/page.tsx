import { Metadata } from 'next'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle } from 'lucide-react'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Panyero - Top Up Success',
  description: 'Your top up was successful',
}

export default function TopUpSuccessPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gray-100">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Top Up Successful</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-4">
          <CheckCircle className="h-16 w-16 text-green-500" />
          <p className="text-center">Your account has been successfully topped up.</p>
          <Button asChild className="w-full">
            <Link href="/top-up">Back to Top Up</Link>
          </Button>
        </CardContent>
      </Card>
    </main>
  )
}

