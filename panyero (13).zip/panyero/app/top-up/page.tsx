'use client'

import { useState } from 'react'
import { TopUpContent } from '@/components/top-up-content'
import { TokenBundles } from '@/components/token-bundles'
import { SubscriptionPlans } from '@/components/subscription-plans'
import { BottomNavigation } from '@/components/bottom-navigation'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TransactionList } from '@/components/transaction-list'

export default function TopUpPage() {
  const [balance, setBalance] = useState(1000) // Initial balance, in a real app this would come from an API or context
  const [transactions, setTransactions] = useState<any[]>([])

  const handleTopUp = (amount: number, userType: string, accountNumber?: string, name?: string) => {
    setBalance(prevBalance => prevBalance + amount)
    setTransactions(prevTransactions => [
      { type: 'Top Up', amount, userType, accountNumber, name, date: new Date().toISOString() },
      ...prevTransactions
    ])
  }

  const handlePurchase = (amount: number) => {
    if (balance >= amount) {
      setBalance(prevBalance => prevBalance - amount)
      return true
    }
    return false
  }

  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Top Up</h1>
        <p className="text-lg">Current Balance: ₱{balance.toFixed(2)}</p>
        <Tabs defaultValue="topup" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="topup">Top Up</TabsTrigger>
            <TabsTrigger value="tokens">Tokens</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
          </TabsList>
          <TabsContent value="topup">
            <TopUpContent onTopUp={handleTopUp} />
          </TabsContent>
          <TabsContent value="tokens">
            <TokenBundles onPurchase={handlePurchase} />
          </TabsContent>
          <TabsContent value="subscriptions">
            <SubscriptionPlans onPurchase={handlePurchase} />
          </TabsContent>
        </Tabs>
        <TransactionList transactions={transactions} />
      </div>
      <BottomNavigation />
    </main>
  )
}

