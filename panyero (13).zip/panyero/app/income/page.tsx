import { Metadata } from 'next'
import { VideoTutorials } from '@/components/video-tutorials'
import { RewardsDashboard } from '@/components/rewards-dashboard'
import { IncomeChart } from '@/components/income-chart'
import { IncomeList } from '@/components/income-list'
import { IncomeSummary } from '@/components/income-summary'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Income & Rewards',
  description: 'Track your income, rewards, and affiliate network',
}

export default function IncomePage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Income & Rewards</h1>
        <VideoTutorials />
        <RewardsDashboard />
        <IncomeSummary />
        <IncomeChart />
        <IncomeList />
      </div>
      <BottomNavigation />
    </main>
  )
}

