import { Metadata } from 'next'
import { RouteStatus } from '@/components/route-status'

export const metadata: Metadata = {
  title: 'Panyero - Route Status',
  description: 'Check the status of all routes',
}

export default function RouteCheckPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-4 p-4 pt-6">
        <h1 className="text-2xl font-bold">Route Status</h1>
        <RouteStatus />
      </div>
    </main>
  )
}

