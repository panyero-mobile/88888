import { Metadata } from 'next'
import { SendMoneyForm } from '@/components/send-money-form'
import { TransactionHistory } from '@/components/transaction-history'
import { BottomNavigation } from '@/components/bottom-navigation'

export const metadata: Metadata = {
  title: 'Panyero - Send Money',
  description: 'Send money quickly and securely with Panyero',
}

export default function SendMoneyPage() {
  return (
    <main className="flex min-h-screen flex-col bg-gray-100">
      <div className="flex-1 space-y-6 p-4 pt-6 pb-20">
        <h1 className="text-2xl font-bold">Send Money</h1>
        <SendMoneyForm />
        <TransactionHistory />
      </div>
      <BottomNavigation />
    </main>
  )
}

