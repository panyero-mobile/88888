// Define the User type if not already defined elsewhere
interface User {
  // Add user properties here
  id: string;
  name: string;
  email: string;
  // Add other properties as needed
}

// Initialize the database
const dbPromise = indexedDB.open('UserDatabase', 1);

dbPromise.onupgradeneeded = (event) => {
  const db = (event.target as IDBOpenDBRequest).result;
  db.createObjectStore('users', { keyPath: 'id' });
};

// Add user
export async function addUser(user: User): Promise<void> {
  const db = await dbPromise;
  const tx = db.transaction('users', 'readwrite');
  const store = tx.objectStore('users');
  return new Promise((resolve, reject) => {
    const request = store.add(user);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// Get user
export async function getUser(id: string): Promise<User | undefined> {
  const db = await dbPromise;
  const tx = db.transaction('users', 'readonly');
  const store = tx.objectStore('users');
  return new Promise((resolve, reject) => {
    const request = store.get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

// Update user
export async function updateUser(user: User): Promise<void> {
  const db = await dbPromise;
  const tx = db.transaction('users', 'readwrite');
  const store = tx.objectStore('users');
  return new Promise((resolve, reject) => {
    const request = store.put(user);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

// Delete user
export async function deleteUser(id: string): Promise<void> {
  const db = await dbPromise;
  const tx = db.transaction('users', 'readwrite');
  const store = tx.objectStore('users');
  return new Promise((resolve, reject) => {
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

