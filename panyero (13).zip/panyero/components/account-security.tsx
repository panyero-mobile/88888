import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Shield, Smartphone } from 'lucide-react'

export function AccountSecurity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Account Security</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button className="w-full justify-start" variant="outline">
          <Shield className="mr-2 h-4 w-4" />
          Change Password
        </Button>
        <Button className="w-full justify-start" variant="outline">
          <Smartphone className="mr-2 h-4 w-4" />
          Two-Factor Authentication
        </Button>
      </CardContent>
    </Card>
  )
}

