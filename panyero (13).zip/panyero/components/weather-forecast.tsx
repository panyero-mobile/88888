'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Cloud, Sun, CloudRain, Wind, MapPin } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ForecastData {
  date: string
  temperature: { min: number; max: number }
  condition: string
  humidity: number
  windSpeed: number
  icon: string
}

const API_KEY = process.env.NEXT_PUBLIC_OPENWEATHER_API_KEY

export function WeatherForecast() {
  const [forecast, setForecast] = useState<ForecastData[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [location, setLocation] = useState('')
  const [coordinates, setCoordinates] = useState({ lat: 0, lng: 0 })

  useEffect(() => {
    fetchForecastData().catch(err => {
      console.error("Error in initial forecast fetch:", err)
      setError('Failed to load initial forecast. Please try searching for a location.')
    })
  }, [])

  const fetchForecastData = async (lat?: number, lon?: number) => {
    setLoading(true)
    setError(null)
    try {
      if (!API_KEY) {
        throw new Error('OpenWeather API key is not configured. Please check your environment variables.')
      }

      let latitude = lat
      let longitude = lon

      if (!latitude || !longitude) {
        try {
          const position = await new Promise<GeolocationPosition>((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
              timeout: 5000,
              maximumAge: 0,
            })
          })
          latitude = position.coords.latitude
          longitude = position.coords.longitude
        } catch (geoError) {
          console.warn("Geolocation error:", geoError)
          // Fallback to a default location (e.g., Manila)
          latitude = 14.5995
          longitude = 120.9842
          setLocation("Manila (Default)")
        }
      }

      setCoordinates({ lat: latitude, lng: longitude })

      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}`
      )
    
      if (!response.ok) {
        throw new Error(`Failed to fetch forecast data: ${response.status} ${response.statusText}`)
      }

      const data = await response.json()
      const dailyForecasts = data.list.filter((_: any, index: number) => index % 8 === 0).slice(0, 5)
      
      setForecast(dailyForecasts.map((day: any) => ({
        date: new Date(day.dt * 1000).toISOString(),
        temperature: { min: Math.round(day.main.temp_min), max: Math.round(day.main.temp_max) },
        condition: day.weather[0].main,
        humidity: day.main.humidity,
        windSpeed: Math.round(day.wind.speed * 3.6),
        icon: day.weather[0].icon
      })))

      if (!location) {
        setLocation(data.city.name)
      }
    } catch (err) {
      console.error('Error fetching forecast data:', err)
      setError(err instanceof Error ? err.message : 'An unknown error occurred while fetching forecast data.')
    } finally {
      setLoading(false)
    }
  }

  const handleLocationChange = async () => {
    if (!location.trim()) {
      setError('Please enter a location')
      return
    }

    setLoading(true)
    setError(null)

    try {
      // Using OpenWeatherMap's Geocoding API instead of Google Maps
      const response = await fetch(
        `https://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(location)}&limit=1&appid=${API_KEY}`
      )
      const data = await response.json()

      if (data && data.length > 0) {
        const { lat, lon } = data[0]
        fetchForecastData(lat, lon)
      } else {
        setError('Location not found. Please try a different search term.')
      }
    } catch (err) {
      setError('Failed to find location. Please try again.')
      console.error(err)
    }
  }

  const getWeatherIcon = (iconCode: string) => {
    switch (iconCode) {
      case '01d':
      case '01n':
        return <Sun className="h-8 w-8 text-yellow-500" />
      case '09d':
      case '09n':
      case '10d':
      case '10n':
        return <CloudRain className="h-8 w-8 text-blue-500" />
      case '03d':
      case '03n':
      case '04d':
      case '04n':
        return <Cloud className="h-8 w-8 text-gray-400" />
      default:
        return <Cloud className="h-8 w-8 text-gray-400" />
    }
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>5-Day Forecast for {location}</span>
            <div className="flex items-center space-x-2">
              <Input
                type="text"
                placeholder="Enter location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="max-w-xs"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleLocationChange()
                  }
                }}
              />
              <Button onClick={handleLocationChange}>Search</Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p>Loading forecast data...</p>
          ) : error ? (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : forecast.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
              {forecast.map((day, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">
                        {new Date(day.date).toLocaleDateString('en-US', { 
                          weekday: 'short', 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                      </h3>
                      {getWeatherIcon(day.icon)}
                    </div>
                    <p className="text-2xl font-bold mb-2">
                      {day.temperature.min}°C - {day.temperature.max}°C
                    </p>
                    <p className="mb-2">{day.condition}</p>
                    <div className="text-sm text-gray-500">
                      <p>Humidity: {day.humidity}%</p>
                      <p>Wind: {day.windSpeed} km/h</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <p>No forecast data available.</p>
          )}
        </CardContent>
      </Card>

      {/* Location Information Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Location Information
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p><strong>Current Location:</strong> {location}</p>
            <p><strong>Coordinates:</strong> {coordinates.lat.toFixed(4)}°, {coordinates.lng.toFixed(4)}°</p>
            <p className="text-sm text-muted-foreground">
              Note: For detailed mapping functionality, please ensure you have configured the Google Maps JavaScript API 
              in your Google Cloud Console and added the API key to your environment variables.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

