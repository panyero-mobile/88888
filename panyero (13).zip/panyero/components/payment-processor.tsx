'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { getUserByAccountNumber } from '@/lib/mockUserDirectory'

interface PaymentProcessorProps {
  accountNumber: string;
  recipientName?: string;
  amount?: number;
  message?: string;
  userBalance: number;
}

export function PaymentProcessor({ accountNumber, recipientName, amount, message, userBalance }: PaymentProcessorProps) {
  const [paymentAmount, setPaymentAmount] = useState(amount?.toString() || '')
  const [paymentMessage, setPaymentMessage] = useState(message || '')
  const recipient = getUserByAccountNumber(accountNumber)

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentAmount(e.target.value)
  }

  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentMessage(e.target.value)
  }

  const isValidAmount = () => {
    const numAmount = parseFloat(paymentAmount)
    return numAmount > 0 && numAmount <= userBalance
  }

  const handleSendNow = () => {
    if (isValidAmount()) {
      alert(`Payment of ₱${paymentAmount} sent to ${recipientName || recipient?.name}`)
      // Here you would typically process the payment
      setPaymentAmount('')
      setPaymentMessage('')
    }
  }

  if (!recipient && !recipientName) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send Payment</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="font-semibold">Recipient:</p>
          <p>{recipientName || recipient?.name}</p>
          <p className="text-sm text-gray-500">Account: {accountNumber}</p>
        </div>
        <div>
          <p className="font-semibold">Amount:</p>
          <Input
            type="number"
            placeholder="Enter amount"
            value={paymentAmount}
            onChange={handleAmountChange}
          />
        </div>
        <div>
          <p className="font-semibold">Message (Optional):</p>
          <Input
            type="text"
            placeholder="Enter message"
            value={paymentMessage}
            onChange={handleMessageChange}
          />
        </div>
        <div>
          <p className="text-sm text-gray-500">Your balance: ₱{userBalance.toFixed(2)}</p>
        </div>
        <Button
          onClick={handleSendNow}
          disabled={!isValidAmount()}
          className={isValidAmount() ? 'bg-green-500 hover:bg-green-600' : ''}
        >
          Send Now
        </Button>
      </CardContent>
    </Card>
  )
}

