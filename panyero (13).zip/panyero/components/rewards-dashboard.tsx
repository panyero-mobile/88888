import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

const levels = [
  { name: 'Level 1', reward: 5, requiredReferrals: 5 },
  { name: 'Level 2', reward: 5, requiredReferrals: 25 },
  { name: 'Level 3', reward: 5, requiredReferrals: 125 },
  { name: 'Level 4', reward: 5, requiredReferrals: 625 },
  { name: 'Level 5', reward: 5, requiredReferrals: 3125 },
]

export function RewardsDashboard() {
  // This would typically come from a database or API
  const currentReferrals = 0
  const totalEarnings = 0

  return (
    <Card>
      <CardHeader>
        <CardTitle>5-Level Unilevel Affiliate Rewards</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {levels.map((level, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between">
                <span className="font-medium">{level.name}</span>
                <span className="text-sm text-muted-foreground">₱{level.reward} per referral</span>
              </div>
              <Progress value={0} className="h-2" />
              <div className="flex justify-between text-sm">
                <span>0 / {level.requiredReferrals} referrals</span>
                <span>0% complete</span>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Your Network</h3>
          <p className="text-2xl font-bold">{currentReferrals}</p>
          <p className="text-sm text-muted-foreground">Total active referrals in your network</p>
        </div>
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Your Current Earnings</h3>
          <p className="text-2xl font-bold">₱{totalEarnings.toFixed(2)}</p>
          <p className="text-sm text-muted-foreground">Start inviting people to earn rewards!</p>
        </div>
      </CardContent>
    </Card>
  )
}

