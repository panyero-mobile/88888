'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Diamond, Gem, Crown, Gift } from 'lucide-react'

interface TokenBundlesProps {
  onPurchase: (amount: number) => boolean
}

const bundles = [
  { price: 50, diamonds: 50, icon: Diamond, color: 'bg-blue-500', name: 'Starter Pack' },
  { price: 100, diamonds: 110, icon: Gem, color: 'bg-green-500', name: 'Value Pack' },
  { price: 500, diamonds: 600, icon: Crown, color: 'bg-purple-500', name: 'Royal Pack' },
  { price: 1000, diamonds: 1300, icon: Gift, color: 'bg-yellow-500', name: 'Mega Pack' },
]

export function TokenBundles({ onPurchase }: TokenBundlesProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handlePurchase(price: number, diamonds: number) {
    setLoading(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const success = onPurchase(price)
      if (success) {
        alert(`Successfully purchased ${diamonds} diamonds for ₱${price}`)
      } else {
        setError('Insufficient balance. Please top up your account.')
      }
    } catch (error) {
      console.error('Error purchasing tokens:', error)
      setError('Failed to purchase tokens. Please try again.')
    }

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Token Bundles</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {bundles.map((bundle, index) => (
            <div key={index} className={`${bundle.color} rounded-lg overflow-hidden shadow-lg transition-transform hover:scale-105`}>
              <div className="p-4 text-white">
                <bundle.icon className="h-12 w-12 mb-2 mx-auto" />
                <h3 className="text-lg font-bold text-center mb-2">{bundle.name}</h3>
                <div className="text-center mb-2">
                  <span className="text-2xl font-bold">{bundle.diamonds}</span>
                  <DiamondIcon className="inline-block h-6 w-6 ml-1" />
                </div>
                <p className="text-center text-xl font-bold mb-4">₱{bundle.price}</p>
                <Button 
                  className="w-full bg-white text-black hover:bg-gray-200"
                  onClick={() => handlePurchase(bundle.price, bundle.diamonds)}
                  disabled={loading}
                >
                  Buy Now
                </Button>
              </div>
            </div>
          ))}
        </div>
        {error && <p className="text-red-500 mt-4">{error}</p>}
      </CardContent>
    </Card>
  )
}

function DiamondIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2.7 10.3l8.8-8.8c.3-.3.7-.3 1 0l8.8 8.8c.3.3.3.7 0 1l-8.8 8.8c-.3.3-.7.3-1 0l-8.8-8.8c-.3-.3-.3-.7 0-1z" />
      <path d="M12 2v20" />
      <path d="M2 12h20" />
    </svg>
  )
}

