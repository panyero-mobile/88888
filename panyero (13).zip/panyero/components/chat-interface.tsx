import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Anchor } from 'lucide-react'
import Link from 'next/link'

export function ChatInterface() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center space-x-2">
        <Anchor className="h-6 w-6" />
        <CardTitle>Kapitan Niyero</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-lg mb-4">How can I assist you today, ka-Panyero?</p>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline">
            <Link href="/weather-update">Weather Update</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/route-check">Route Check</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

