'use client'

import { useState, useEffect, useRef } from 'react'
import { Html5Qrcode } from 'html5-qrcode'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Camera, StopCircle } from 'lucide-react'
import { isActiveAccount, getUserByAccountNumber } from '@/lib/mockUserDirectory'

interface QRCodeScannerProps {
  onValidScan: (accountNumber: string) => void;
}

export function QRCodeScanner({ onValidScan }: QRCodeScannerProps) {
  const [scanning, setScanning] = useState(false)
  const [scanResult, setScanResult] = useState<{ valid: boolean; message: string } | null>(null)
  const scannerRef = useRef<Html5Qrcode | null>(null)

  useEffect(() => {
    return () => {
      if (scannerRef.current) {
        scannerRef.current.clear()
      }
    }
  }, [])

  const startScanning = () => {
    setScanning(true)
    setScanResult(null)

    const config = { fps: 10, qrbox: { width: 250, height: 250 } }

    Html5Qrcode.getCameras()
      .then(devices => {
        if (devices && devices.length) {
          scannerRef.current = new Html5Qrcode('reader')
          scannerRef.current.start(
            { facingMode: 'environment' },
            config,
            onScanSuccess,
            onScanFailure
          )
        }
      })
      .catch(err => console.error('Error getting cameras', err))
  }

  const stopScanning = () => {
    if (scannerRef.current) {
      scannerRef.current.stop().then(() => {
        setScanning(false)
      })
    }
  }

  const onScanSuccess = (decodedText: string) => {
    stopScanning()
    if (isActiveAccount(decodedText)) {
      setScanResult({ valid: true, message: 'Valid account found!' })
      onValidScan(decodedText)
    } else {
      setScanResult({ valid: false, message: 'Invalid or inactive account.' })
    }
  }

  const onScanFailure = (error: string) => {
    console.warn(`QR code scan error: ${error}`)
  }

  return (
    <Card className="flex justify-center items-center p-6">
      <CardContent className="flex flex-col items-center space-y-6">
        <div id="reader" className="w-64 h-64 bg-gray-200 flex items-center justify-center rounded-lg overflow-hidden">
          {!scanning && <Camera className="h-12 w-12 text-gray-400" />}
        </div>
        {!scanning && !scanResult && (
          <Button onClick={startScanning} className="w-full">
            <Camera className="mr-2 h-4 w-4" />
            Start Scanning
          </Button>
        )}
        {scanning && (
          <Button onClick={stopScanning} variant="destructive" className="w-full">
            <StopCircle className="mr-2 h-4 w-4" />
            Stop Scanning
          </Button>
        )}
        {scanResult && (
          <div className={`text-center ${scanResult.valid ? 'text-green-600' : 'text-red-600'}`}>
            <p className="font-semibold">{scanResult.message}</p>
            <Button onClick={() => setScanResult(null)} className="mt-2 w-full">
              Scan Again
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

