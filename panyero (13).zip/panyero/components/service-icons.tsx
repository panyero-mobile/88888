import React from 'react'

// Custom 3D-style SVG icons
const ServiceIcon = ({ children, color = "#4834d4" }) => (
  <svg
    viewBox="0 0 24 24"
    className="h-8 w-8"
    style={{ filter: 'drop-shadow(0px 4px 6px rgba(0, 0, 0, 0.1))' }}
  >
    <defs>
      <linearGradient id={`gradient-${color}`} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style={{ stopColor: color, stopOpacity: 1 }} />
        <stop offset="100%" style={{ stopColor: darkenColor(color, 20), stopOpacity: 1 }} />
      </linearGradient>
    </defs>
    {children}
  </svg>
)

// Helper function to darken colors
function darkenColor(color: string, amount: number): string {
  const hex = color.replace('#', '')
  const num = parseInt(hex, 16)
  const r = Math.max(0, (num >> 16) - amount)
  const b = Math.max(0, ((num >> 8) & 0x00FF) - amount)
  const g = Math.max(0, (num & 0x0000FF) - amount)
  return `#${(g | (b << 8) | (r << 16)).toString(16).padStart(6, '0')}`
}

export const InternetIcon = () => (
  <ServiceIcon color="#4834d4">
    <path
      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"
      fill="url(#gradient-#4834d4)"
    />
  </ServiceIcon>
)

export const WaterIcon = () => (
  <ServiceIcon color="#00b0ff">
    <path
      d="M12 2c-5.33 4.55-8 8.48-8 11.8 0 4.98 3.8 8.2 8 8.2s8-3.22 8-8.2c0-3.32-2.67-7.25-8-11.8zm0 18c-3.35 0-6-2.57-6-6.2 0-2.34 1.95-5.44 6-9.14 4.05 3.7 6 6.79 6 9.14 0 3.63-2.65 6.2-6 6.2z"
      fill="url(#gradient-#00b0ff)"
    />
  </ServiceIcon>
)

export const ElectricityIcon = () => (
  <ServiceIcon color="#ffd600">
    <path
      d="M7 2v11h3v9l7-12h-4l4-8z"
      fill="url(#gradient-#ffd600)"
    />
  </ServiceIcon>
)

export const TVIcon = () => (
  <ServiceIcon color="#ff4081">
    <path
      d="M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 1.99-.9 1.99-2L23 5c0-1.1-.9-2-2-2zm0 14H3V5h18v12z"
      fill="url(#gradient-#ff4081)"
    />
  </ServiceIcon>
)

export const LoadIcon = () => (
  <ServiceIcon color="#00e676">
    <path
      d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14z"
      fill="url(#gradient-#00e676)"
    />
  </ServiceIcon>
)

export const RentIcon = () => (
  <ServiceIcon color="#7c4dff">
    <path
      d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"
      fill="url(#gradient-#7c4dff)"
    />
  </ServiceIcon>
)

export const LotteryIcon = () => (
  <ServiceIcon color="#ff6e40">
    <path
      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"
      fill="url(#gradient-#ff6e40)"
    />
    <circle cx="12" cy="12" r="3" fill="url(#gradient-#ff6e40)" />
  </ServiceIcon>
)

export const GamesIcon = () => (
  <ServiceIcon color="#1de9b6">
    <path
      d="M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v3H6v-3H3v-2h3V8h2v3h3v2zm4.5 2c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm4-3c-.83 0-1.5-.67-1.5-1.5S18.67 9 19.5 9s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"
      fill="url(#gradient-#1de9b6)"
    />
  </ServiceIcon>
)

export const CasinoIcon = () => (
  <ServiceIcon color="#ff1744">
    <path
      d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"
      fill="url(#gradient-#ff1744)"
    />
  </ServiceIcon>
)

export const AIPersonaIcon = () => (
  <ServiceIcon color="#aa00ff">
    <path
      d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"
      fill="url(#gradient-#aa00ff)"
    />
  </ServiceIcon>
)

