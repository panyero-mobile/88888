import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function IncomeSummary() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Income Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">This Month</p>
            <p className="text-2xl font-bold">₱0.00</p>
            <p className="text-sm text-muted-foreground">No earnings yet</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Earnings</p>
            <p className="text-2xl font-bold">₱0.00</p>
            <p className="text-sm text-muted-foreground">Start earning by inviting friends!</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

