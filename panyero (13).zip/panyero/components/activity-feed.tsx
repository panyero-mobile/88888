import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activities = [
  { user: "John Doe", action: "sent you", amount: "₱50.00", time: "2 hours ago" },
  { user: "Jane Smith", action: "requested", amount: "₱100.00", time: "5 hours ago" },
  { user: "Mike Johnson", action: "paid", amount: "₱75.00", time: "Yesterday" },
  { user: "Sarah Williams", action: "received", amount: "₱200.00", time: "2 days ago" },
]

export function ActivityFeed() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div key={index} className="flex items-center space-x-4">
              <Avatar>
                <AvatarImage src={`https://i.pravatar.cc/150?u=${activity.user}`} alt={activity.user} />
                <AvatarFallback>{activity.user.split(' ').map(n => n[0]).join('')}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <p className="text-sm font-medium">{activity.user} {activity.action}</p>
                <p className="text-sm text-muted-foreground">{activity.amount}</p>
              </div>
              <p className="text-sm text-muted-foreground">{activity.time}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

