import React from 'react';
import { Dice1Icon as Dice } from 'lucide-react';

const games = [
  { name: "BlackJ", url: "https://panyero.website/BlackJ" },
  { name: "Roulett", url: "https://panyero.website/Roulett" },
  { name: "Baccara", url: "https://panyero.website/Baccara" },
  { name: "Poker", url: "https://panyero.website/Poker" },
  { name: "DragonT", url: "https://panyero.website/DragonT" },
  { name: "Craps", url: "https://panyero.website/Craps" },
  { name: "GameShw", url: "https://panyero.website/GameShw" },
  { name: "Keno", url: "https://panyero.website/Keno" },
  { name: "Monopol", url: "https://panyero.website/Monopol" },
  { name: "DealNoD", url: "https://panyero.website/DealNoD" },
  { name: "MegaBal", url: "https://panyero.website/MegaBal" },
  { name: "TeenPat", url: "https://panyero.website/TeenPat" },
  { name: "FootStu", url: "https://panyero.website/FootStu" },
  { name: "CasinoH", url: "https://panyero.website/CasinoH" },
  { name: "3CrdPok", url: "https://panyero.website/3CrdPok" },
  { name: "CaribSt", url: "https://panyero.website/CaribSt" },
  { name: "UTexasH", url: "https://panyero.website/UTexasH" },
  { name: "LightDC", url: "https://panyero.website/LightDC" },
];

export function GamesSection() {
  return (
    <div className="games grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-4">
      {games.map((game) => (
        <a key={game.name} href={game.url} target="_blank" rel="noopener noreferrer" className="inline-block">
          <div className="flex flex-col items-center">
            <Dice className="h-10 w-10 text-gray-600" />
            <span className="text-xs mt-1">{game.name}</span>
          </div>
        </a>
      ))}
    </div>
  );
}

