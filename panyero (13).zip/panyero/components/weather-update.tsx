'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Cloud, Sun, CloudRain, Wind } from 'lucide-react'
import Link from 'next/link'
import { Alert, AlertDescription } from "@/components/ui/alert"

interface WeatherData {
  location: string
  temperature: number
  condition: string
  humidity: number
  windSpeed: number
  icon: string
}

// Attempt to get the API key from environment variables
const API_KEY = process.env.NEXT_PUBLIC_OPENWEATHER_API_KEY || '';

export function WeatherUpdate() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [fallbackLocation, setFallbackLocation] = useState<string | null>(null)

  useEffect(() => {
    fetchWeatherData()
  }, [])

  const fetchWeatherData = async () => {
    setLoading(true);
    setError(null);
    try {
      if (!API_KEY) {
        throw new Error('OpenWeather API key is not configured. Please check your environment variables.');
      }

      let latitude: number, longitude: number;

      try {
        const position = await new Promise<GeolocationPosition>((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject, {
            timeout: 5000,
            maximumAge: 0,
          });
        });
        latitude = position.coords.latitude;
        longitude = position.coords.longitude;
      } catch (geoError) {
        console.warn("Geolocation error:", geoError);
        // Fallback to a default location (e.g., Manila)
        latitude = 14.5995;
        longitude = 120.9842;
        setFallbackLocation("Using default location (Manila)");
      }

      const url = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}`;
      console.log('Fetching weather data from:', url.replace(API_KEY, 'API_KEY')); // Log URL without exposing API key

      const response = await fetch(url);
      
      if (!response.ok) {
        const responseText = await response.text();
        throw new Error(`Failed to fetch weather data: ${response.status} ${response.statusText}
Response: ${responseText}`);
      }

      const data = await response.json();
      setWeather({
        location: data.name,
        temperature: Math.round(data.main.temp),
        condition: data.weather[0].main,
        humidity: data.main.humidity,
        windSpeed: Math.round(data.wind.speed * 3.6), // Convert m/s to km/h
        icon: data.weather[0].icon
      });
    } catch (err) {
      console.error('Error fetching weather data:', err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred while fetching weather data.');
    } finally {
      setLoading(false);
    }
  }

  const getWeatherIcon = (iconCode: string) => {
    switch (iconCode) {
      case '01d':
      case '01n':
        return <Sun className="h-8 w-8 text-yellow-500" />
      case '09d':
      case '09n':
      case '10d':
      case '10n':
        return <CloudRain className="h-8 w-8 text-blue-500" />
      case '03d':
      case '03n':
      case '04d':
      case '04n':
        return <Cloud className="h-8 w-8 text-gray-400" />
      default:
        return <Cloud className="h-8 w-8 text-gray-400" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Weather Update</span>
          <Button variant="ghost" size="sm" onClick={fetchWeatherData} disabled={loading}>
            Refresh
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p>Loading weather data...</p>
        ) : error ? (
          <Alert variant="destructive">
            <AlertDescription>
              <p>{error}</p>
              {error.includes('API key') && (
                <p className="text-sm mt-2">
                  Please make sure the NEXT_PUBLIC_OPENWEATHER_API_KEY is set in your .env.local file or Vercel environment variables.
                </p>
              )}
              <p className="text-sm mt-2">
                If the error persists, please check the browser console for more details.
              </p>
            </AlertDescription>
          </Alert>
        ) : weather ? (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">{weather.location}</h3>
              {getWeatherIcon(weather.icon)}
            </div>
            <p className="text-3xl font-bold">{weather.temperature}°C</p>
            <p>{weather.condition}</p>
            <div className="flex justify-between text-sm text-gray-500">
              <span>Humidity: {weather.humidity}%</span>
              <span>Wind: {weather.windSpeed} km/h</span>
            </div>
          </div>
        ) : (
          <p>No weather data available.</p>
        )}
        {fallbackLocation && (
          <p className="text-sm text-yellow-600 mt-2">{fallbackLocation}</p>
        )}
        <Link href="/weather-update" className="text-sm text-blue-500 hover:underline mt-4 inline-block">
          View detailed forecast
        </Link>
      </CardContent>
    </Card>
  )
}

