'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { isActiveAccount } from '@/lib/mockUserDirectory'

interface ManualAccountEntryProps {
  onValidAccount: (accountNumber: string, name: string, amount: number, message: string) => void;
}

export function ManualAccountEntry({ onValidAccount }: ManualAccountEntryProps) {
  const [accountNumber, setAccountNumber] = useState('')
  const [name, setName] = useState('')
  const [amount, setAmount] = useState('')
  const [message, setMessage] = useState('')
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!accountNumber || !name || !amount) {
      setError('Please fill in all required fields.')
      return
    }

    if (isActiveAccount(accountNumber)) {
      onValidAccount(accountNumber, name, parseFloat(amount), message)
    } else {
      setError('Invalid or inactive Panyero account.')
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manual Account Entry</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="accountNumber">Account Number (Phone Number)</Label>
            <Input
              id="accountNumber"
              type="tel"
              placeholder="Enter account number"
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Recipient's Name</Label>
            <Input
              id="name"
              type="text"
              placeholder="Enter recipient's name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="amount">Amount to Send</Label>
            <Input
              id="amount"
              type="number"
              placeholder="Enter amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message (Optional)</Label>
            <Input
              id="message"
              type="text"
              placeholder="Enter message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <Button type="submit" className="w-full">Send Payment</Button>
        </form>
      </CardContent>
    </Card>
  )
}

