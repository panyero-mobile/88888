'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { supabase } from '@/lib/supabase'

interface WeatherData {
  id: number
  location: string
  temperature: number
  condition: string
  updated_at: string
}

export function WeatherUpdateContent() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)

  useEffect(() => {
    fetchWeatherData()
  }, [])

  async function fetchWeatherData() {
    const { data, error } = await supabase
      .from('weather_data')
      .select('*')
      .order('updated_at', { ascending: false })
      .limit(1)
      .single()

    if (error) console.error('Error fetching weather data:', error)
    else setWeatherData(data)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Current Weather</CardTitle>
      </CardHeader>
      <CardContent>
        {weatherData ? (
          <div className="space-y-2">
            <p><strong>Location:</strong> {weatherData.location}</p>
            <p><strong>Temperature:</strong> {weatherData.temperature}°C</p>
            <p><strong>Condition:</strong> {weatherData.condition}</p>
            <p><strong>Last Updated:</strong> {new Date(weatherData.updated_at).toLocaleString()}</p>
          </div>
        ) : (
          <p>Loading weather data...</p>
        )}
        <Button onClick={fetchWeatherData} className="mt-4">Refresh</Button>
      </CardContent>
    </Card>
  )
}

