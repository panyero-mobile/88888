import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Bet {
  gameId: string
  numbers: number[]
  amount: number
  drawDate: string
  drawTime: string
}

interface PlacedBetsListProps {
  bets: Bet[]
}

export function PlacedBetsList({ bets }: PlacedBetsListProps) {
  if (bets.length === 0) {
    return null
  }

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Your Placed Bets</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {bets.map((bet, index) => (
            <div key={index} className="bg-gray-100 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold">Game: {bet.gameId}</span>
                <span className="text-sm text-gray-600">₱{bet.amount.toFixed(2)}</span>
              </div>
              <div className="flex space-x-2 mb-2">
                {bet.numbers.map((number, idx) => (
                  <div key={idx} className="w-8 h-8 rounded-full bg-yellow-500 text-white flex items-center justify-center text-xs font-bold">
                    {number.toString().padStart(2, '0')}
                  </div>
                ))}
              </div>
              <div className="text-sm text-gray-600">
                Draw: {bet.drawDate} {bet.drawTime}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

