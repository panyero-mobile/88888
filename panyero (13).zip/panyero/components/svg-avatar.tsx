import React from 'react'

interface SVGAvatarProps {
  name: string
  className?: string
}

export function SVGAvatar({ name, className = "" }: SVGAvatarProps) {
  // Generate a hash code from the name
  const hash = name.split('').reduce((acc, char) => {
    return char.charCodeAt(0) + ((acc << 5) - acc)
  }, 0)

  // Generate a color based on the hash
  const color = `hsl(${hash % 360}, 70%, 60%)`

  // Generate a simple pattern based on the hash
  const patternId = `pattern-${name.replace(/\s+/g, '-').toLowerCase()}`
  const patternSize = 4
  const patternElements = []
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if ((hash + i * 4 + j) % 2 === 0) {
        patternElements.push(
          <rect
            key={`${i}-${j}`}
            x={i * patternSize}
            y={j * patternSize}
            width={patternSize}
            height={patternSize}
            fill={color}
          />
        )
      }
    }
  }

  return (
    <svg
      className={`rounded-full ${className}`}
      viewBox="0 0 40 40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern
          id={patternId}
          patternUnits="userSpaceOnUse"
          width="16"
          height="16"
        >
          {patternElements}
        </pattern>
      </defs>
      <circle cx="20" cy="20" r="20" fill={`url(#${patternId})`} />
    </svg>
  )
}

