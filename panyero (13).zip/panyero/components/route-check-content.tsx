'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface RouteStatus {
  id: number
  route_name: string
  status: string
  last_updated: string
}

export function RouteCheckContent() {
  const [routes, setRoutes] = useState<RouteStatus[]>([])
  const [newRoute, setNewRoute] = useState({ route_name: '', status: 'Normal' })

  useEffect(() => {
    fetchRoutes()
  }, [])

  async function fetchRoutes() {
    const { data, error } = await supabase
      .from('route_status')
      .select('*')
      .order('route_name', { ascending: true })

    if (error) console.error('Error fetching routes:', error)
    else setRoutes(data || [])
  }

  async function addRoute() {
    const { data, error } = await supabase
      .from('route_status')
      .insert([{ ...newRoute, last_updated: new Date().toISOString() }])

    if (error) console.error('Error adding route:', error)
    else {
      fetchRoutes()
      setNewRoute({ route_name: '', status: 'Normal' })
    }
  }

  async function updateRouteStatus(id: number, status: string) {
    const { error } = await supabase
      .from('route_status')
      .update({ status, last_updated: new Date().toISOString() })
      .eq('id', id)

    if (error) console.error('Error updating route status:', error)
    else fetchRoutes()
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Route Statuses</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {routes.map((route) => (
              <div key={route.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">{route.route_name}</h3>
                  <p className="text-sm text-muted-foreground">Status: {route.status}</p>
                  <p className="text-xs text-muted-foreground">Last updated: {new Date(route.last_updated).toLocaleString()}</p>
                </div>
                <div>
                  <Button
                    variant="outline"
                    onClick={() => updateRouteStatus(route.id, 'Normal')}
                    className="mr-2"
                  >
                    Normal
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => updateRouteStatus(route.id, 'Delayed')}
                    className="mr-2"
                  >
                    Delayed
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => updateRouteStatus(route.id, 'Closed')}
                  >
                    Closed
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Route</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-2">
            <Input
              placeholder="Route Name"
              value={newRoute.route_name}
              onChange={(e) => setNewRoute({ ...newRoute, route_name: e.target.value })}
            />
            <Button onClick={addRoute}>Add Route</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

