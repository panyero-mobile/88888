import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Transaction {
  type: string
  amount: number
  userType: string
  accountNumber?: string
  name?: string
  date: string
}

interface TransactionListProps {
  transactions: Transaction[]
}

export function TransactionList({ transactions }: TransactionListProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction, index) => (
            <div key={index} className="flex justify-between items-center border-b pb-2">
              <div>
                <p className="font-medium">{transaction.type}</p>
                <p className="text-sm text-gray-500">
                  {transaction.userType === 'merchant' ? `${transaction.name} (${transaction.accountNumber})` : transaction.userType}
                </p>
                <p className="text-xs text-gray-400">{new Date(transaction.date).toLocaleString()}</p>
              </div>
              <p className="font-medium text-green-500">+₱{transaction.amount.toFixed(2)}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

