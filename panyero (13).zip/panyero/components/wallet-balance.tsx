import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { PlusCircle, ArrowUpRight } from 'lucide-react'

export function WalletBalance() {
  return (
    <Card className="bg-white">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-xl font-semibold">Hi, Juan</h2>
            <p className="text-sm text-muted-foreground">Your available balance</p>
          </div>
          <Button variant="outline" size="icon">
            <PlusCircle className="h-4 w-4" />
          </Button>
        </div>
        <p className="text-3xl font-bold mb-2">₱12,500.00</p>
        <div className="flex items-center text-green-500">
          <ArrowUpRight className="h-4 w-4 mr-1" />
          <span className="text-sm">+₱500 this week</span>
        </div>
      </CardContent>
    </Card>
  )
}

