'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Clock } from 'lucide-react'

interface RouteData {
  name: string
  status: 'On Time' | 'Delayed' | 'Cancelled'
  message?: string
  lastUpdated: string
}

export function RouteStatus() {
  const [routes, setRoutes] = useState<RouteData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRouteData()
  }, [])

  const fetchRouteData = async () => {
    setLoading(true)
    // In a real app, this would be an API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setRoutes([
      { name: 'Route 1', status: 'On Time', lastUpdated: '2023-06-10T10:30:00Z' },
      { name: 'Route 2', status: 'Delayed', message: '15 minutes delay due to traffic', lastUpdated: '2023-06-10T10:45:00Z' },
      { name: 'Route 3', status: 'Cancelled', message: 'Service cancelled due to maintenance', lastUpdated: '2023-06-10T09:00:00Z' },
      { name: 'Route 4', status: 'On Time', lastUpdated: '2023-06-10T10:15:00Z' },
      { name: 'Route 5', status: 'Delayed', message: '10 minutes delay due to road work', lastUpdated: '2023-06-10T10:40:00Z' },
    ])
    setLoading(false)
  }

  const getStatusIcon = (status: RouteData['status']) => {
    switch (status) {
      case 'On Time':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'Delayed':
        return <Clock className="h-5 w-5 text-yellow-500" />
      case 'Cancelled':
        return <AlertTriangle className="h-5 w-5 text-red-500" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>All Routes Status</span>
          <Button variant="ghost" size="sm" onClick={fetchRouteData} disabled={loading}>
            Refresh
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p>Loading route data...</p>
        ) : routes.length > 0 ? (
          <div className="space-y-4">
            {routes.map((route, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold">{route.name}</h3>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(route.status)}
                      <span className={`text-sm ${
                        route.status === 'On Time' ? 'text-green-500' :
                        route.status === 'Delayed' ? 'text-yellow-500' : 'text-red-500'
                      }`}>
                        {route.status}
                      </span>
                    </div>
                  </div>
                  {route.message && (
                    <p className="text-sm text-gray-600 mb-2">{route.message}</p>
                  )}
                  <p className="text-xs text-gray-400">
                    Last updated: {new Date(route.lastUpdated).toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <p>No route data available.</p>
        )}
      </CardContent>
    </Card>
  )
}

