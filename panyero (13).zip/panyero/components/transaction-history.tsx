import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const transactions = [
  { name: "Alice", amount: 50, date: "2023-06-01", type: "sent" },
  { name: "Bob", amount: 30, date: "2023-05-30", type: "received" },
  { name: "Charlie", amount: 100, date: "2023-05-28", type: "sent" },
]

export function TransactionHistory() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {transactions.map((transaction, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between p-2 rounded-lg transition-all duration-200 hover:bg-gray-100"
            >
              <div className="flex items-center space-x-4">
                <Avatar>
                  <AvatarImage src={`https://i.pravatar.cc/150?u=${transaction.name.toLowerCase()}`} alt={transaction.name} />
                  <AvatarFallback>{transaction.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{transaction.name}</p>
                  <p className="text-sm text-gray-500">{transaction.date}</p>
                </div>
              </div>
              <p className={`font-medium ${transaction.type === 'sent' ? 'text-red-500' : 'text-green-500'}`}>
                {transaction.type === 'sent' ? '-' : '+'}₱{transaction.amount}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

