import React from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

interface TicketConfirmationModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  gameInfo: {
    name: string
    drawDate: string
    drawTime: string
  }
  selectedNumbers: number[]
  betAmount: number
  expectedWinning: number
}

export function TicketConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  gameInfo,
  selectedNumbers,
  betAmount,
  expectedWinning
}: TicketConfirmationModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Confirm Your Bet</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Game:</span>
            <span>{gameInfo.name}</span>
          </div>
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Draw Date:</span>
            <span>{gameInfo.drawDate}</span>
          </div>
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Draw Time:</span>
            <span>{gameInfo.drawTime}</span>
          </div>
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Selected Numbers:</span>
            <span>{selectedNumbers.join(', ')}</span>
          </div>
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Bet Amount:</span>
            <span>₱{betAmount.toFixed(2)}</span>
          </div>
          <div className="grid grid-cols-2 items-center gap-4">
            <span className="font-semibold">Expected Winning:</span>
            <span>₱{expectedWinning.toFixed(2)}</span>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={onConfirm}>Confirm Bet</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

