import Link from "next/link"
import {
  InternetIcon,
  WaterIcon,
  ElectricityIcon,
  TVIcon,
  LoadIcon,
  RentIcon,
  LotteryIcon,
  GamesIcon,
} from './service-icons'

const services = [
  { icon: InternetIcon, label: "Net", href: "http://panyero.website/Net" },
  { icon: WaterIcon, label: "Water", href: "http://panyero.website/Water" },
  { icon: ElectricityIcon, label: "Electric", href: "http://panyero.website/Electric" },
  { icon: TVIcon, label: "TV", href: "http://panyero.website/TV" },
  { icon: LoadIcon, label: "Load", href: "http://panyero.website/Load" },
  { icon: RentIcon, label: "Rent", href: "http://panyero.website/Rent" },
  { icon: LotteryIcon, label: "Lottery", href: "http://panyero.website/Lottery" },
  { icon: GamesIcon, label: "Games", href: "http://panyero.website/Games" },
]

export function ServicesGrid() {
  return (
    <div className="grid grid-cols-4 gap-4">
      {services.map((service) => (
        <Link
          key={service.label}
          href={service.href}
          className="flex flex-col items-center space-y-2 p-4 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-200 hover:-translate-y-1"
        >
          <service.icon />
          <span className="text-sm font-medium text-gray-700">{service.label}</span>
        </Link>
      ))}
    </div>
  )
}

