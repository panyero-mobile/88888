import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const users = [
  { name: "John", image: "https://github.com/shadcn.png" },
  { name: "Sarah", image: "https://github.com/shadcn.png" },
  { name: "Mike", image: "https://github.com/shadcn.png" },
  { name: "Lisa", image: "https://github.com/shadcn.png" },
  { name: "David", image: "https://github.com/shadcn.png" },
]

export function UserScroll() {
  return (
    <ScrollArea className="w-full whitespace-nowrap rounded-md border">
      <div className="flex w-max space-x-4 p-4">
        {users.map((user) => (
          <div key={user.name} className="flex flex-col items-center space-y-1">
            <Avatar className="h-12 w-12">
              <AvatarImage src={user.image} alt={user.name} />
              <AvatarFallback>{user.name[0]}</AvatarFallback>
            </Avatar>
            <span className="text-xs">{user.name}</span>
          </div>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  )
}

