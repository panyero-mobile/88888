'use client'
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Bell, QrCode, BarChart3, Grid } from 'lucide-react'

export function BottomNavigation() {
  const pathname = usePathname()

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t bg-white pt-2"> 
      <div className="flex items-center justify-around p-4">
        <NavItem href="/" icon={Home} label="Home" isActive={pathname === '/'} />
        <NavItem href="/activity" icon={Bell} label="Activity" isActive={pathname === '/activity'} />
        <NavItem href="/pay" icon={QrCode} label="Pay" isCenter isActive={pathname === '/pay' || pathname === '/services'} />
        <NavItem href="/income" icon={BarChart3} label="Income" isActive={pathname === '/income'} />
        <NavItem href="/services" icon={Grid} label="Services" isActive={pathname === '/services'} />
      </div>
    </div>
  )
}

function NavItem({ href, icon: Icon, label, isCenter = false, isActive = false }) {
  return (
    <Link href={href} className={`flex flex-col items-center space-y-1 ${isCenter ? 'relative -top-6' : ''}`}>
      {isCenter ? (
        <div className={`rounded-full p-4 shadow-lg ${isActive ? 'bg-blue-500' : 'bg-black'}`}>
          <Icon className="h-6 w-6 text-white" />
        </div>
      ) : (
        <Icon className={`h-6 w-6 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
      )}
      <span className={`text-xs ${isActive ? 'text-blue-500 font-medium' : 'text-gray-500'}`}>{label}</span>
    </Link>
  )
}

