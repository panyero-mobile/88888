import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const incomeItems = [
  { source: "Salary", amount: "₱25,000.00", date: "June 1, 2023" },
  { source: "Freelance Work", amount: "₱5,000.00", date: "June 15, 2023" },
  { source: "Investment Dividends", amount: "₱2,500.00", date: "June 20, 2023" },
  { source: "Side Project", amount: "₱3,000.00", date: "June 25, 2023" },
]

export function IncomeList() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Income Sources</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {incomeItems.map((item, index) => (
            <div key={index} className="flex justify-between items-center">
              <div>
                <p className="font-medium">{item.source}</p>
                <p className="text-sm text-muted-foreground">{item.date}</p>
              </div>
              <p className="font-medium">{item.amount}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

