import React from 'react';
import { User } from 'lucide-react';

const aiPersonas = [
  { name: "Doctor", url: "https://panyero.website/Doctor" },
  { name: "Attorney", url: "https://panyero.website/Attorney" },
  { name: "Captain", url: "https://panyero.website/Captain" },
  { name: "Pilot", url: "https://panyero.website/Pilot" },
  { name: "Teacher", url: "https://panyero.website/Teacher" },
  { name: "Nurse", url: "https://panyero.website/Nurse" },
  { name: "Driver", url: "https://panyero.website/Driver" },
  { name: "Agent", url: "https://panyero.website/Agent" },
  { name: "Manager", url: "https://panyero.website/Manager" },
  { name: "Engineer", url: "https://panyero.website/Engineer" },
  { name: "Chef", url: "https://panyero.website/Chef" },
  { name: "Artist", url: "https://panyero.website/Artist" },
];

export function AIPersonaSection() {
  return (
    <div className="ai-persona grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-4">
      {aiPersonas.map((persona) => (
        <a key={persona.name} href={persona.url} target="_blank" rel="noopener noreferrer" className="inline-block">
          <div className="flex flex-col items-center">
            <User className="h-10 w-10 text-gray-600" />
            <span className="text-xs mt-1">{persona.name}</span>
          </div>
        </a>
      ))}
    </div>
  );
}

