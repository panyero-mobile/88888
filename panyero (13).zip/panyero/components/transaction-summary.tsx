import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function TransactionSummary() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
            <p className="text-2xl font-bold">₱15,250.00</p>
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Total Received</p>
            <p className="text-2xl font-bold">₱22,750.00</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

