'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, CheckCircle, Clock } from 'lucide-react'
import Link from 'next/link'

interface RouteStatus {
  name: string
  status: 'On Time' | 'Delayed' | 'Cancelled'
  message?: string
}

export function RouteCheck() {
  const [routes, setRoutes] = useState<RouteStatus[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchRouteData()
  }, [])

  const fetchRouteData = async () => {
    setLoading(true)
    // In a real app, this would be an API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    setRoutes([
      { name: 'Route 1', status: 'On Time' },
      { name: 'Route 2', status: 'Delayed', message: '15 minutes delay due to traffic' },
      { name: 'Route 3', status: 'Cancelled', message: 'Service cancelled due to maintenance' },
    ])
    setLoading(false)
  }

  const getStatusIcon = (status: RouteStatus['status']) => {
    switch (status) {
      case 'On Time':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'Delayed':
        return <Clock className="h-5 w-5 text-yellow-500" />
      case 'Cancelled':
        return <AlertTriangle className="h-5 w-5 text-red-500" />
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Route Check</span>
          <Button variant="ghost" size="sm" onClick={fetchRouteData} disabled={loading}>
            Refresh
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <p>Loading route data...</p>
        ) : routes.length > 0 ? (
          <ul className="space-y-2">
            {routes.map((route, index) => (
              <li key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {getStatusIcon(route.status)}
                  <span>{route.name}</span>
                </div>
                <span className={`text-sm ${
                  route.status === 'On Time' ? 'text-green-500' :
                  route.status === 'Delayed' ? 'text-yellow-500' : 'text-red-500'
                }`}>
                  {route.status}
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p>No route data available.</p>
        )}
        <Link href="/route-check" className="text-sm text-blue-500 hover:underline mt-4 inline-block">
          View all routes
        </Link>
      </CardContent>
    </Card>
  )
}

