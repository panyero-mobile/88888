import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export function RecentTransaction() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Recent Transaction</h2>
        <Link href="#" className="text-sm text-blue-600 hover:underline">
          See All
        </Link>
      </div>
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <Avatar>
              <AvatarImage src="https://github.com/shadcn.png" alt="Raj K" />
              <AvatarFallback>RK</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <p className="font-medium">Raj Kumar</p>
              <p className="text-sm text-muted-foreground">February 24, 2022</p>
            </div>
            <p className="font-medium">₱20.00</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

