import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export function PromoBanner() {
  return (
    <Card className="overflow-hidden bg-gradient-to-r from-pink-500 to-purple-500">
      <CardContent className="p-6">
        <div className="flex items-center">
          <div className="flex-1 text-white">
            <h3 className="font-semibold text-2xl mb-2">50% OFF</h3>
            <p className="text-lg mb-1">Summer special deal</p>
            <p className="text-sm mb-4">
              Get discount for every transaction until August 31
            </p>
            <Button variant="secondary">Claim Now</Button>
          </div>
          <Image
            src="/placeholder.svg"
            alt="Summer Promo"
            width={120}
            height={120}
            className="rounded-lg"
          />
        </div>
      </CardContent>
    </Card>
  )
}

