import React, { useState } from 'react'
import { Sheet, SheetContent, SheetFooter, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface PinConfirmationSheetProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: (pin: string) => void
}

export function PinConfirmationSheet({ isOpen, onClose, onConfirm }: PinConfirmationSheetProps) {
  const [pin, setPin] = useState('')

  const handleConfirm = () => {
    if (pin.length === 6) {
      onConfirm(pin)
      setPin('')
    }
  }

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="bottom" className="sm:max-w-[425px]">
        <SheetHeader>
          <SheetTitle>Confirm Your Bet</SheetTitle>
        </SheetHeader>
        <div className="grid gap-4 py-4">
          <Input
            type="password"
            placeholder="Enter your 6-digit PIN"
            value={pin}
            onChange={(e) => setPin(e.target.value.slice(0, 6))}
            maxLength={6}
            pattern="\d{6}"
            inputMode="numeric"
          />
        </div>
        <SheetFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleConfirm} disabled={pin.length !== 6}>Confirm</Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}

