'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

const contacts = [
  { name: "Alice", image: "https://i.pravatar.cc/150?u=alice", number: "1234567890" },
  { name: "Bob", image: "https://i.pravatar.cc/150?u=bob", number: "2345678901" },
  { name: "Charlie", image: "https://i.pravatar.cc/150?u=charlie", number: "3456789012" },
  { name: "David", image: "https://i.pravatar.cc/150?u=david", number: "4567890123" },
]

export function RecentContacts() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Contacts</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex space-x-4 overflow-x-auto pb-2">
          {contacts.map((contact) => (
            <Button
              key={contact.name}
              variant="outline"
              className="flex flex-col items-center space-y-1 p-2 transition-all duration-200 hover:bg-gray-100 hover:scale-105"
            >
              <Avatar className="h-12 w-12">
                <AvatarImage src={contact.image} alt={contact.name} />
                <AvatarFallback>{contact.name[0]}</AvatarFallback>
              </Avatar>
              <span className="text-xs">{contact.name}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

