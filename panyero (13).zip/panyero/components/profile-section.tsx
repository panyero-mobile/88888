import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import Link from 'next/link'

export function ProfileSection() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center space-y-4">
        <Avatar className="h-24 w-24">
          <AvatarImage src="https://github.com/shadcn.png" alt="User" />
          <AvatarFallback>UN</AvatarFallback>
        </Avatar>
        <div className="text-center">
          <h2 className="text-xl font-bold">Juan Dela Cruz</h2>
          <p className="text-sm text-muted-foreground">juan@example.com</p>
        </div>
        <Button asChild>
          <Link href="/update-profile">Update Profile</Link>
        </Button>
      </CardContent>
    </Card>
  )
}

