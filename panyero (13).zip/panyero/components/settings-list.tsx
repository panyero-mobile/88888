import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

const settingsItems = [
  { label: "Push Notifications", id: "push-notifications" },
  { label: "Email Notifications", id: "email-notifications" },
  { label: "SMS Notifications", id: "sms-notifications" },
  { label: "Dark Mode", id: "dark-mode" },
]

export function SettingsList() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {settingsItems.map((item) => (
            <div key={item.id} className="flex items-center justify-between">
              <Label htmlFor={item.id}>{item.label}</Label>
              <Switch id={item.id} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

