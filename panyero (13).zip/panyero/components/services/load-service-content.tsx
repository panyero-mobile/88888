'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { supabase } from '@/lib/supabase'

interface LoadPackage {
  id: number
  name: string
  amount: number
  validity: string
}

export function LoadServiceContent() {
  const [packages, setPackages] = useState<LoadPackage[]>([])
  const [newPackage, setNewPackage] = useState({ name: '', amount: 0, validity: '' })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedPackage, setSelectedPackage] = useState<string | null>(null)
  const [phoneNumber, setPhoneNumber] = useState('')

  useEffect(() => {
    fetchPackages()
  }, [])

  async function fetchPackages() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('load_packages')
      .select('*')
    if (error) {
      console.error('Error fetching packages:', error)
      setError('Failed to fetch packages. Please try again.')
    } else {
      setPackages(data || [])
    }
    setLoading(false)
  }

  async function addPackage() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('load_packages')
      .insert([newPackage])
    if (error) {
      console.error('Error adding package:', error)
      setError('Failed to add package. Please try again.')
    } else {
      await fetchPackages()
      setNewPackage({ name: '', amount: 0, validity: '' })
    }
    setLoading(false)
  }

  async function purchaseLoad() {
    if (!selectedPackage || !phoneNumber) {
      setError('Please select a package and enter a phone number.')
      return
    }
    setLoading(true)
    setError(null)
    const { error } = await supabase
      .from('load_transactions')
      .insert([{ package_id: selectedPackage, phone_number: phoneNumber }])
    if (error) {
      console.error('Error purchasing load:', error)
      setError('Failed to purchase load. Please try again.')
    } else {
      alert('Load purchased successfully!')
      setSelectedPackage(null)
      setPhoneNumber('')
    }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Purchase Load</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading packages...</p>}
          {error && <p className="text-red-500">{error}</p>}
          <div className="space-y-2">
            <Select onValueChange={setSelectedPackage}>
              <SelectTrigger>
                <SelectValue placeholder="Select a package" />
              </SelectTrigger>
              <SelectContent>
                {packages.map((pkg) => (
                  <SelectItem key={pkg.id} value={pkg.id.toString()}>
                    {pkg.name} - ₱{pkg.amount} ({pkg.validity})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              placeholder="Phone Number"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
            />
            <Button onClick={purchaseLoad} disabled={loading}>Purchase Load</Button>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Package</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Package Name"
              value={newPackage.name}
              onChange={(e) => setNewPackage({ ...newPackage, name: e.target.value })}
            />
            <Input
              type="number"
              placeholder="Amount"
              value={newPackage.amount}
              onChange={(e) => setNewPackage({ ...newPackage, amount: Number(e.target.value) })}
            />
            <Input
              placeholder="Validity"
              value={newPackage.validity}
              onChange={(e) => setNewPackage({ ...newPackage, validity: e.target.value })}
            />
            <Button onClick={addPackage} disabled={loading}>Add Package</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

