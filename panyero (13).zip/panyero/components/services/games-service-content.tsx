'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Mail, Dice1Icon as Dice } from 'lucide-react'

const liveCasinoGames = [
  "Blackjack",
  "Roulette",
  "Baccarat",
  "Poker",
  "Sic Bo",
  "Dragon Tiger",
  "Craps",
  "Game Shows",
  "Keno",
  "Monopoly",
  "Deal or No Deal",
  "Mega Ball",
  "Andar Bahar",
  "Teen Patti",
  "Football Studio",
  "Casino Hold'em",
  "Three Card Poker",
  "Caribbean Stud",
  "Ultimate Texas Hold'em",
  "Lightning Dice"
]

const lotteryGames = [
  "Lotto",
  "Powerball"
]

export function GamesServiceContent() {
  const [selectedGame, setSelectedGame] = useState<string | null>(null)

  const handleGameSelect = (game: string) => {
    setSelectedGame(game)
    // In a real app, this would navigate to the game
    alert(`Selected game: ${game}`)
  }

  return (
    <div className="space-y-6">
      {/* Live Casino Section */}
      <Card>
        <CardHeader className="flex flex-row items-center space-x-2">
          <Mail className="h-6 w-6 text-green-600" />
          <CardTitle className="text-xl text-green-600">Live Casino</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {liveCasinoGames.map((game) => (
              <Button
                key={game}
                variant="outline"
                className="h-auto py-4 px-4 flex items-center justify-center text-center bg-gray-50 hover:bg-gray-100"
                onClick={() => handleGameSelect(game)}
              >
                {game}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Lottery Section */}
      <Card>
        <CardHeader className="flex flex-row items-center space-x-2">
          <Dice className="h-6 w-6 text-green-600" />
          <CardTitle className="text-xl text-green-600">Lottery</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-2">
            {lotteryGames.map((game) => (
              <Button
                key={game}
                variant="outline"
                className="h-auto py-4 px-4 flex items-center justify-center text-center bg-gray-50 hover:bg-gray-100"
                onClick={() => handleGameSelect(game)}
              >
                {game}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

