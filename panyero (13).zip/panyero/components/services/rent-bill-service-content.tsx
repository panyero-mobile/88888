'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface RentBill {
  id: number
  month: string
  amount: number
  status: string
}

export function RentBillServiceContent() {
  const [bills, setBills] = useState<RentBill[]>([])
  const [newBill, setNewBill] = useState({ month: '', amount: 0, status: 'Unpaid' })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchBills()
  }, [])

  async function fetchBills() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('rent_bills')
      .select('*')
    if (error) {
      console.error('Error fetching bills:', error)
      setError('Failed to fetch bills. Please try again.')
    } else {
      setBills(data || [])
    }
    setLoading(false)
  }

  async function addBill() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('rent_bills')
      .insert([newBill])
    if (error) {
      console.error('Error adding bill:', error)
      setError('Failed to add bill. Please try again.')
    } else {
      await fetchBills()
      setNewBill({ month: '', amount: 0, status: 'Unpaid' })
    }
    setLoading(false)
  }

  async function updateBillStatus(id: number, status: string) {
    setLoading(true)
    setError(null)
    const { error } = await supabase
      .from('rent_bills')
      .update({ status })
      .eq('id', id)
    if (error) {
      console.error('Error updating bill status:', error)
      setError('Failed to update bill status. Please try again.')
    } else {
      await fetchBills()
    }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Rent Bills</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading bills...</p>}
          {error && <p className="text-red-500">{error}</p>}
          <div className="space-y-2">
            {bills.map((bill) => (
              <div key={bill.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">{bill.month}</h3>
                  <p className="text-sm text-muted-foreground">₱{bill.amount} - {bill.status}</p>
                </div>
                {bill.status === 'Unpaid' && (
                  <Button onClick={() => updateBillStatus(bill.id, 'Paid')} disabled={loading}>Mark as Paid</Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Bill</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Month"
              value={newBill.month}
              onChange={(e) => setNewBill({ ...newBill, month: e.target.value })}
            />
            <Input
              type="number"
              placeholder="Amount"
              value={newBill.amount}
              onChange={(e) => setNewBill({ ...newBill, amount: Number(e.target.value) })}
            />
            <Button onClick={addBill} disabled={loading}>Add Bill</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

