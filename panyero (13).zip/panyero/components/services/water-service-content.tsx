'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface WaterBill {
  id: number
  month: string
  amount: number
  status: string
}

export function WaterServiceContent() {
  const [bills, setBills] = useState<WaterBill[]>([])
  const [newBill, setNewBill] = useState({ month: '', amount: 0, status: 'Unpaid' })

  useEffect(() => {
    fetchBills()
  }, [])

  async function fetchBills() {
    const { data, error } = await supabase
      .from('water_bills')
      .select('*')
    if (error) console.error('Error fetching bills:', error)
    else setBills(data || [])
  }

  async function addBill() {
    const { data, error } = await supabase
      .from('water_bills')
      .insert([newBill])
    if (error) console.error('Error adding bill:', error)
    else {
      fetchBills()
      setNewBill({ month: '', amount: 0, status: 'Unpaid' })
    }
  }

  async function updateBillStatus(id: number, status: string) {
    const { error } = await supabase
      .from('water_bills')
      .update({ status })
      .eq('id', id)
    if (error) console.error('Error updating bill status:', error)
    else fetchBills()
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Water Bills</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {bills.map((bill) => (
              <div key={bill.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">{bill.month}</h3>
                  <p className="text-sm text-muted-foreground">₱{bill.amount} - {bill.status}</p>
                </div>
                {bill.status === 'Unpaid' && (
                  <Button onClick={() => updateBillStatus(bill.id, 'Paid')}>Mark as Paid</Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Bill</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Month"
              value={newBill.month}
              onChange={(e) => setNewBill({ ...newBill, month: e.target.value })}
            />
            <Input
              type="number"
              placeholder="Amount"
              value={newBill.amount}
              onChange={(e) => setNewBill({ ...newBill, amount: Number(e.target.value) })}
            />
            <Button onClick={addBill}>Add Bill</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

