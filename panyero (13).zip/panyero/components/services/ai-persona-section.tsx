import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const aiPersonas = [
  { name: "Doctor", url: "https://your-url.com/Doctor" },
  { name: "Attorney", url: "https://your-url.com/Attorney" },
  { name: "Captain", url: "https://your-url.com/Captain" },
  { name: "Pilot", url: "https://your-url.com/Pilot" },
  { name: "Teacher", url: "https://your-url.com/Teacher" },
  { name: "Nurse", url: "https://your-url.com/Nurse" },
  { name: "Driver", url: "https://your-url.com/Driver" },
  { name: "Agent", url: "https://your-url.com/Agent" },
  { name: "Manager", url: "https://your-url.com/Manager" },
  { name: "Engineer", url: "https://your-url.com/Engineer" },
  { name: "Chef", url: "https://your-url.com/Chef" },
  { name: "Artist", url: "https://your-url.com/Artist" },
]

export function AIPersonaSection() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Persona</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {aiPersonas.map((persona) => (
            <Button
              key={persona.name}
              onClick={() => window.open(persona.url, '_blank', 'fullscreen')}
              variant="outline"
              className="w-full"
            >
              {persona.name}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

