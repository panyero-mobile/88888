import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const games = [
  { name: "BlackJ", url: "https://your-url.com/BlackJ" },
  { name: "Roulett", url: "https://your-url.com/Roulett" },
  { name: "Baccara", url: "https://your-url.com/Baccara" },
  { name: "Poker", url: "https://your-url.com/Poker" },
  { name: "DragonT", url: "https://your-url.com/DragonT" },
  { name: "Craps", url: "https://your-url.com/Craps" },
  { name: "GameShw", url: "https://your-url.com/GameShw" },
  { name: "Keno", url: "https://your-url.com/Keno" },
  { name: "Monopol", url: "https://your-url.com/Monopol" },
  { name: "DealNoD", url: "https://your-url.com/DealNoD" },
  { name: "MegaBal", url: "https://your-url.com/MegaBal" },
  { name: "TeenPat", url: "https://your-url.com/TeenPat" },
  { name: "FootStu", url: "https://your-url.com/FootStu" },
  { name: "CasinoH", url: "https://your-url.com/CasinoH" },
  { name: "3CrdPok", url: "https://your-url.com/3CrdPok" },
  { name: "CaribSt", url: "https://your-url.com/CaribSt" },
  { name: "UTexasH", url: "https://your-url.com/UTexasH" },
  { name: "LightDC", url: "https://your-url.com/LightDC" },
]

export function GamesSection() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Games</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {games.map((game) => (
            <Button
              key={game.name}
              onClick={() => window.open(game.url, '_blank', 'fullscreen')}
              variant="outline"
              className="w-full"
            >
              {game.name}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

