'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface TVCablePackage {
  id: number
  name: string
  channels: number
  price: number
}

export function TVCableServiceContent() {
  const [packages, setPackages] = useState<TVCablePackage[]>([])
  const [newPackage, setNewPackage] = useState({ name: '', channels: 0, price: 0 })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchPackages()
  }, [])

  async function fetchPackages() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('tv_cable_packages')
      .select('*')
    if (error) {
      console.error('Error fetching packages:', error)
      setError('Failed to fetch packages. Please try again.')
    } else {
      setPackages(data || [])
    }
    setLoading(false)
  }

  async function addPackage() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('tv_cable_packages')
      .insert([newPackage])
    if (error) {
      console.error('Error adding package:', error)
      setError('Failed to add package. Please try again.')
    } else {
      await fetchPackages()
      setNewPackage({ name: '', channels: 0, price: 0 })
    }
    setLoading(false)
  }

  async function deletePackage(id: number) {
    setLoading(true)
    setError(null)
    const { error } = await supabase
      .from('tv_cable_packages')
      .delete()
      .eq('id', id)
    if (error) {
      console.error('Error deleting package:', error)
      setError('Failed to delete package. Please try again.')
    } else {
      await fetchPackages()
    }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Available TV Cable Packages</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading packages...</p>}
          {error && <p className="text-red-500">{error}</p>}
          <div className="space-y-2">
            {packages.map((pkg) => (
              <div key={pkg.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">{pkg.name}</h3>
                  <p className="text-sm text-muted-foreground">{pkg.channels} channels - ₱{pkg.price}/month</p>
                </div>
                <Button variant="destructive" onClick={() => deletePackage(pkg.id)} disabled={loading}>Delete</Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Package</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Package Name"
              value={newPackage.name}
              onChange={(e) => setNewPackage({ ...newPackage, name: e.target.value })}
            />
            <Input
              type="number"
              placeholder="Number of Channels"
              value={newPackage.channels}
              onChange={(e) => setNewPackage({ ...newPackage, channels: Number(e.target.value) })}
            />
            <Input
              type="number"
              placeholder="Price"
              value={newPackage.price}
              onChange={(e) => setNewPackage({ ...newPackage, price: Number(e.target.value) })}
            />
            <Button onClick={addPackage} disabled={loading}>Add Package</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

