'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface InternetPlan {
  id: number
  name: string
  speed: string
  price: number
}

export function InternetServiceContent() {
  const [plans, setPlans] = useState<InternetPlan[]>([])
  const [newPlan, setNewPlan] = useState({ name: '', speed: '', price: 0 })

  useEffect(() => {
    fetchPlans()
  }, [])

  async function fetchPlans() {
    const { data, error } = await supabase
      .from('internet_plans')
      .select('*')
    if (error) console.error('Error fetching plans:', error)
    else setPlans(data || [])
  }

  async function addPlan() {
    const { data, error } = await supabase
      .from('internet_plans')
      .insert([newPlan])
    if (error) console.error('Error adding plan:', error)
    else {
      fetchPlans()
      setNewPlan({ name: '', speed: '', price: 0 })
    }
  }

  async function deletePlan(id: number) {
    const { error } = await supabase
      .from('internet_plans')
      .delete()
      .eq('id', id)
    if (error) console.error('Error deleting plan:', error)
    else fetchPlans()
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Available Internet Plans</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {plans.map((plan) => (
              <div key={plan.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">{plan.name}</h3>
                  <p className="text-sm text-muted-foreground">{plan.speed} - ₱{plan.price}/month</p>
                </div>
                <Button variant="destructive" onClick={() => deletePlan(plan.id)}>Delete</Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Add New Plan</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Plan Name"
              value={newPlan.name}
              onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
            />
            <Input
              placeholder="Speed"
              value={newPlan.speed}
              onChange={(e) => setNewPlan({ ...newPlan, speed: e.target.value })}
            />
            <Input
              type="number"
              placeholder="Price"
              value={newPlan.price}
              onChange={(e) => setNewPlan({ ...newPlan, price: Number(e.target.value) })}
            />
            <Button onClick={addPlan}>Add Plan</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

