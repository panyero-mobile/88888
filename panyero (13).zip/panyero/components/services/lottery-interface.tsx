'use client'

import { useState, useEffect } from 'react'
import { Trophy, Clock, History } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getLatestDrawResult, getNextDraw, getDrawHistory, DrawResult, NextDraw } from '@/lib/mockPcsoApi'
import { TicketConfirmationModal } from '@/components/ticket-confirmation-modal'
import { PinConfirmationSheet } from '@/components/pin-confirmation-sheet'
import { PlacedBetsList } from '@/components/placed-bets-list'

interface LottoGame {
  id: string
  name: string
  description: string
  prize: string
  maxNumber: number
}

const lottoGames: LottoGame[] = [
  { id: '642', name: '6/42 Lotto', description: 'First 2 numbers from 6/42 draw', prize: '₱700', maxNumber: 42 },
  { id: '645', name: '6/45 Mega Lotto', description: 'First 2 numbers from 6/45 draw', prize: '₱800', maxNumber: 45 },
  { id: '649', name: '6/49 Super Lotto', description: 'First 2 numbers from 6/49 draw', prize: '₱900', maxNumber: 49 },
  { id: '655', name: '6/55 Grand Lotto', description: 'First 2 numbers from 6/55 draw', prize: '₱1,100', maxNumber: 55 },
  { id: '658', name: '6/58 Ultra Lotto', description: 'First 2 numbers from 6/58 draw', prize: '₱1,200', maxNumber: 58 },
]

function LottoBall({ number, selected, onClick, disabled }: { number: number; selected: boolean; onClick: () => void; disabled: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${
        selected ? 'bg-yellow-500 text-white' : 'bg-gray-200 text-gray-800'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-yellow-400'}`}
    >
      {number.toString().padStart(2, '0')}
    </button>
  )
}

export function LotteryInterface() {
  const [selectedGame, setSelectedGame] = useState<LottoGame>(lottoGames[0])
  const [betAmount, setBetAmount] = useState('')
  const [selectedNumbers, setSelectedNumbers] = useState<number[]>([])
  const [availableNumbers, setAvailableNumbers] = useState<number[]>([])
  const [latestDraws, setLatestDraws] = useState<Record<string, DrawResult>>({})
  const [nextDraws, setNextDraws] = useState<Record<string, NextDraw>>({})
  const [drawHistories, setDrawHistories] = useState<Record<string, DrawResult[]>>({})
  const [walletBalance, setWalletBalance] = useState(1000)
  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false)
  const [currentBets, setCurrentBets] = useState<Record<string, number>>({})
  const [latestDraw, setLatestDraw] = useState<DrawResult | null>(null);
  const [nextDraw, setNextDraw] = useState<NextDraw | null>(null);
  const [isPinConfirmationOpen, setIsPinConfirmationOpen] = useState(false)
  const [placedBets, setPlacedBets] = useState<Array<{
    gameId: string,
    numbers: number[],
    amount: number,
    drawDate: string,
    drawTime: string
  }>>([])


  useEffect(() => {
    lottoGames.forEach(game => {
      setLatestDraws(prev => ({ ...prev, [game.id]: getLatestDrawResult() }))
      setNextDraws(prev => ({ ...prev, [game.id]: getNextDraw() }))
      setDrawHistories(prev => ({ ...prev, [game.id]: getDrawHistory() }))
    })
  }, [])

  useEffect(() => {
    setAvailableNumbers(Array.from({ length: selectedGame.maxNumber }, (_, i) => i + 1))
    setSelectedNumbers([])
  }, [selectedGame])

  useEffect(() => {
    if (selectedGame) {
      const latestDrawResult = getLatestDrawResult();
      setLatestDraw(latestDrawResult);

      const nextDrawInfo = getNextDraw();
      setNextDraw(nextDrawInfo);
    }
  }, [selectedGame]);


  const handleNumberSelect = (number: number) => {
    if (selectedNumbers.includes(number)) {
      setSelectedNumbers(selectedNumbers.filter(n => n !== number))
    } else if (selectedNumbers.length < 2) {
      setSelectedNumbers([...selectedNumbers, number])
    }
  }

  const handlePlaceBet = () => {
    if (!selectedGame || !betAmount || selectedNumbers.length !== 2) {
      alert('Please select a game, enter bet amount, and choose two numbers.')
      return
    }

    const betAmountNumber = parseFloat(betAmount)
    if (betAmountNumber < 10) {
      alert('Minimum bet amount is ₱10.')
      return
    }

    if (betAmountNumber > walletBalance) {
      alert('Insufficient balance in your wallet.')
      return
    }

    const totalCombinations = calculateTotalCombinations(selectedGame.maxNumber)
    const currentGameBets = currentBets[selectedGame.id] || 0
    const newTotalBets = currentGameBets + 1

    if (newTotalBets > totalCombinations * 0.7) {
      alert('Betting limit reached for this game. Please try a different game or number combination.')
      return
    }

    setIsConfirmationModalOpen(true)
  }

  const confirmBet = () => {
    setIsConfirmationModalOpen(false)
    setIsPinConfirmationOpen(true)
  }

  const handlePinConfirmation = (pin: string) => {
    // Here you would typically validate the PIN against the user's stored PIN
    // For this example, we'll just simulate a successful confirmation
    setIsPinConfirmationOpen(false)

    const betAmountNumber = parseFloat(betAmount)
    setWalletBalance(prevBalance => prevBalance - betAmountNumber)
    setCurrentBets(prevBets => ({
      ...prevBets,
      [selectedGame!.id]: (prevBets[selectedGame!.id] || 0) + 1
    }))

    // Add the new bet to the placedBets list
    setPlacedBets(prevBets => [
      ...prevBets,
      {
        gameId: selectedGame!.id,
        numbers: selectedNumbers,
        amount: betAmountNumber,
        drawDate: nextDraw!.drawDate,
        drawTime: nextDraw!.drawTime
      }
    ])

    alert('Bet placed successfully!')
    setBetAmount('')
    setSelectedNumbers([])
  }

  const calculateTotalCombinations = (maxNumber: number) => {
    return (maxNumber * (maxNumber - 1)) / 2
  }

  const calculateExpectedWinning = () => {
    if (!selectedGame || !betAmount) return 0
    const prizeAmount = parseFloat(selectedGame.prize.replace('₱', ''))
    return parseFloat(betAmount) * (prizeAmount / 100) // Assuming the prize is for a ₱100 bet
  }

  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
  };

  return (
    <div className="min-h-screen bg-white p-4 text-gray-800">
      {/* Header */}
      <Card className="bg-gray-100 p-4 mb-6 rounded-xl sticky top-0 z-10">
        <div className="flex items-center space-x-3">
          <Trophy className="h-8 w-8 text-yellow-600" />
          <div>
            <h1 className="text-xl font-bold">Panyero F2-Numbers</h1>
            <p className="text-sm text-gray-600">Based on Philippine Charity Sweepstakes</p>
          </div>
        </div>
      </Card>

      <Tabs defaultValue={lottoGames[0].id} className="w-full">
        <TabsList className="grid w-full grid-cols-5 gap-2 p-1 bg-gray-200 rounded-lg">
          {lottoGames.map(game => (
            <TabsTrigger
              key={game.id}
              value={game.id}
              onClick={() => setSelectedGame(game)}
              className="px-2 py-1 text-sm font-medium rounded-md transition-colors duration-150 ease-in-out hover:bg-gray-300 data-[state=active]:bg-white data-[state=active]:shadow-sm whitespace-nowrap overflow-hidden text-ellipsis"
            >
              {game.name}
            </TabsTrigger>
          ))}
        </TabsList>
        {lottoGames.map(game => (
          <TabsContent key={game.id} value={game.id}>
            {/* Latest Draw Result */}
            {latestDraw && (
              <Card className="bg-gray-100 p-4 mb-6 rounded-xl">
                <div className="flex justify-between items-center mb-2">
                  <h2 className="text-lg font-bold text-yellow-600">{latestDraw.gameName}</h2>
                  <p className="text-sm text-gray-600">{formatDate(latestDraw.drawDate)} {latestDraw.drawTime}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <p className="text-sm text-gray-600 mr-2">Winning Numbers:</p>
                  {latestDraw.numbers.map((number, index) => (
                    <div key={index} className="w-8 h-8 rounded-full bg-yellow-500 text-white flex items-center justify-center text-xs font-bold">
                      {number.toString().padStart(2, '0')}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Next Draw */}
            {nextDraw && (
              <Card className="bg-gray-100 p-4 mb-6 rounded-xl">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-gray-800">Next Draw: {nextDraw.gameName}</h3>
                    <p className="text-sm text-gray-600">{formatDate(nextDraw.drawDate)} {nextDraw.drawTime}</p>
                  </div>
                  <Clock className="h-6 w-6 text-yellow-600" />
                </div>
              </Card>
            )}


            {/* Number Selection */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Select Your Numbers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-6 gap-2">
                  {availableNumbers.map((number) => (
                    <LottoBall
                      key={number}
                      number={number}
                      selected={selectedNumbers.includes(number)}
                      onClick={() => handleNumberSelect(number)}
                      disabled={selectedNumbers.length === 2 && !selectedNumbers.includes(number)}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Betting Interface */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Place Your Bet</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Input
                    type="number"
                    placeholder="Bet Amount (₱)"
                    value={betAmount}
                    onChange={(e) => setBetAmount(e.target.value)}
                    className="bg-white border-gray-300 text-gray-800 placeholder-gray-400"
                  />
                  <div className="flex space-x-2">
                    {selectedNumbers.map((number, index) => (
                      <div key={index} className="w-10 h-10 rounded-full bg-yellow-500 text-white flex items-center justify-center text-sm font-bold">
                        {number.toString().padStart(2, '0')}
                      </div>
                    ))}
                  </div>
                  <Button onClick={handlePlaceBet} className="w-full bg-blue-500 text-white hover:bg-blue-600" disabled={selectedNumbers.length !== 2 || !betAmount}>
                    Place Bet
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Draw History */}
            <Card>
              <CardHeader>
                <CardTitle>Draw History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {drawHistories[game.id]?.slice(0, 3).map((draw, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">{formatDate(draw.drawDate)} {draw.drawTime}</p>
                      </div>
                      <div className="flex space-x-1">
                        {draw.numbers.map((number, idx) => (
                          <div key={idx} className="w-8 h-8 rounded-full bg-yellow-500 text-white flex items-center justify-center text-xs font-bold">
                            {number.toString().padStart(2, '0')}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Wallet Balance */}
      <Card className="mt-6">
        <CardContent className="flex justify-between items-center p-4">
          <span className="text-sm text-gray-600">Wallet Balance</span>
          <span className="font-bold text-gray-800">₱{walletBalance.toFixed(2)}</span>
        </CardContent>
      </Card>

      <TicketConfirmationModal
        isOpen={isConfirmationModalOpen}
        onClose={() => setIsConfirmationModalOpen(false)}
        onConfirm={confirmBet}
        gameInfo={{
          name: selectedGame?.name || '',
          drawDate: nextDraws[selectedGame?.id]?.drawDate || '',
          drawTime: nextDraws[selectedGame?.id]?.drawTime || '',
        }}
        selectedNumbers={selectedNumbers}
        betAmount={parseFloat(betAmount)}
        expectedWinning={calculateExpectedWinning()}
      />

      <PinConfirmationSheet
        isOpen={isPinConfirmationOpen}
        onClose={() => setIsPinConfirmationOpen(false)}
        onConfirm={handlePinConfirmation}
      />
      <PlacedBetsList bets={placedBets} />
    </div>
  )
}

