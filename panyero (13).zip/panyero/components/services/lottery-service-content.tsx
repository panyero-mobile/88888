'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

interface LotteryTicket {
  id: number
  numbers: string
  draw_date: string
  status: string
}

export function LotteryServiceContent() {
  const [tickets, setTickets] = useState<LotteryTicket[]>([])
  const [newTicket, setNewTicket] = useState({ numbers: '', draw_date: '' })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchTickets()
  }, [])

  async function fetchTickets() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('lottery_tickets')
      .select('*')
    if (error) {
      console.error('Error fetching tickets:', error)
      setError('Failed to fetch tickets. Please try again.')
    } else {
      setTickets(data || [])
    }
    setLoading(false)
  }

  async function buyTicket() {
    setLoading(true)
    setError(null)
    const { data, error } = await supabase
      .from('lottery_tickets')
      .insert([{ ...newTicket, status: 'Pending' }])
    if (error) {
      console.error('Error buying ticket:', error)
      setError('Failed to buy ticket. Please try again.')
    } else {
      await fetchTickets()
      setNewTicket({ numbers: '', draw_date: '' })
    }
    setLoading(false)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Your Lottery Tickets</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading tickets...</p>}
          {error && <p className="text-red-500">{error}</p>}
          <div className="space-y-2">
            {tickets.map((ticket) => (
              <div key={ticket.id} className="flex justify-between items-center p-2 bg-white rounded-lg shadow">
                <div>
                  <h3 className="font-semibold">Numbers: {ticket.numbers}</h3>
                  <p className="text-sm text-muted-foreground">Draw Date: {ticket.draw_date}</p>
                  <p className="text-sm text-muted-foreground">Status: {ticket.status}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Buy New Ticket</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Input
              placeholder="Lottery Numbers (comma-separated)"
              value={newTicket.numbers}
              onChange={(e) => setNewTicket({ ...newTicket, numbers: e.target.value })}
            />
            <Input
              type="date"
              placeholder="Draw Date"
              value={newTicket.draw_date}
              onChange={(e) => setNewTicket({ ...newTicket, draw_date: e.target.value })}
            />
            <Button onClick={buyTicket} disabled={loading}>Buy Ticket</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

