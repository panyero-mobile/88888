'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

export function SendMoneyContent() {
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSendMoney() {
    if (!recipient || !amount) return

    setLoading(true)
    setError(null)

    const { data, error } = await supabase
      .from('transactions')
      .insert([
        { type: 'send', recipient, amount: parseFloat(amount) }
      ])

    if (error) {
      console.error('Error sending money:', error)
      setError('Failed to send money. Please try again.')
    } else {
      alert(`Successfully sent ₱${amount} to ${recipient}`)
      setRecipient('')
      setAmount('')
    }

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Send Money to a Friend</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            placeholder="Recipient's name or number"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
          />
          <Input
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Button onClick={handleSendMoney} className="w-full" disabled={loading}>
            {loading ? 'Processing...' : 'Send Money'}
          </Button>
          {error && <p className="text-red-500">{error}</p>}
        </div>
      </CardContent>
    </Card>
  )
}

