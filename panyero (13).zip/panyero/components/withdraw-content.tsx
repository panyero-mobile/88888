'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from '@/lib/supabase'

export function WithdrawContent() {
  const [amount, setAmount] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleWithdraw() {
    if (!amount || !accountNumber) return

    setLoading(true)
    setError(null)

    const { data, error } = await supabase
      .from('transactions')
      .insert([
        { type: 'withdraw', amount: parseFloat(amount), account_number: accountNumber }
      ])

    if (error) {
      console.error('Error withdrawing funds:', error)
      setError('Failed to withdraw funds. Please try again.')
    } else {
      alert(`Successfully withdrew ₱${amount} to account ${accountNumber}`)
      setAmount('')
      setAccountNumber('')
    }

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Withdraw Funds</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Input
            type="number"
            placeholder="Enter amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Input
            placeholder="Enter bank account number"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
          />
          <Button onClick={handleWithdraw} className="w-full" disabled={loading}>
            {loading ? 'Processing...' : 'Withdraw'}
          </Button>
          {error && <p className="text-red-500">{error}</p>}
        </div>
      </CardContent>
    </Card>
  )
}

