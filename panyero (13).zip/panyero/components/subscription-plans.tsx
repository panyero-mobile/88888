'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check } from 'lucide-react'

interface SubscriptionPlansProps {
  onPurchase: (amount: number) => boolean
}

const plans = [
  { name: 'Free', price: 0, features: ['Basic access'] },
  { name: 'Affiliate', price: 100, features: ['Basic access', 'Affiliation program'] },
  { name: 'Premium', price: 500, features: ['Full access to all services', 'Affiliation program', 'Priority support'] },
]

export function SubscriptionPlans({ onPurchase }: SubscriptionPlansProps) {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubscribe(plan: string, price: number) {
    setLoading(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const success = onPurchase(price)
      if (success) {
        alert(`Successfully subscribed to ${plan} plan`)
      } else {
        setError('Insufficient balance. Please top up your account.')
      }
    } catch (error) {
      console.error('Error subscribing:', error)
      setError('Failed to subscribe. Please try again.')
    }

    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscription Plans</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-3">
          {plans.map((plan, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle>{plan.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold mb-4">₱{plan.price}</p>
                <ul className="space-y-2 mb-4">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center">
                      <Check className="h-4 w-4 mr-2 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className="w-full"
                  onClick={() => handleSubscribe(plan.name, plan.price)}
                  disabled={loading}
                >
                  Subscribe
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        {error && <p className="text-red-500 mt-4">{error}</p>}
      </CardContent>
    </Card>
  )
}

