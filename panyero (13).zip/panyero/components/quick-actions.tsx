import Link from "next/link"
import { Button } from "@/components/ui/button"
import { PlusIcon, ArrowUpIcon, ArrowDownIcon } from 'lucide-react'

export function QuickActions() {
  return (
    <div className="grid grid-cols-3 gap-2">
      <Button asChild className="w-full bg-gray-800 text-white hover:bg-gray-700 shadow-md">
        <Link href="/top-up" className="flex flex-col items-center justify-center h-24">
          <PlusIcon className="h-6 w-6 mb-1" />
          <span className="text-xs">Top Up</span>
        </Link>
      </Button>
      <Button asChild className="w-full bg-gray-800 text-white hover:bg-gray-700 shadow-md">
        <Link href="/send-money" className="flex flex-col items-center justify-center h-24">
          <ArrowUpIcon className="h-6 w-6 mb-1" />
          <span className="text-xs">Send</span>
        </Link>
      </Button>
      <Button asChild className="w-full bg-gray-800 text-white hover:bg-gray-700 shadow-md">
        <Link href="/withdraw" className="flex flex-col items-center justify-center h-24">
          <ArrowDownIcon className="h-6 w-6 mb-1" />
          <span className="text-xs">Withdraw</span>
        </Link>
      </Button>
    </div>
  )
}

