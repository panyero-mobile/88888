'use client'

import { useState, useRef, useEffect } from 'react'
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { QRCodeSVG } from 'qrcode.react'
import { Share2, Download, Mail, MessageCircle, Phone } from 'lucide-react'
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu"

interface QRCodeGeneratorProps {
  accountNumber: string
}

export function QRCodeGenerator({ accountNumber }: QRCodeGeneratorProps) {
  const [showQR, setShowQR] = useState(false)
  const qrRef = useRef<SVGSVGElement>(null)

  const toggleQRCode = () => {
    setShowQR(!showQR)
  }

  const shareQRCode = (method: string) => {
    const shareData = {
      title: 'My Panyero Account QR Code',
      text: 'Scan this QR code to pay me using Panyero',
      url: `panyero://pay/${accountNumber}`
    }

    switch (method) {
      case 'messenger':
        window.open(`https://www.facebook.com/dialog/send?link=${encodeURIComponent(shareData.url)}&app_id=YOUR_FACEBOOK_APP_ID`, '_blank')
        break
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(`${shareData.text} ${shareData.url}`)}`, '_blank')
        break
      case 'email':
        window.open(`mailto:?subject=${encodeURIComponent(shareData.title)}&body=${encodeURIComponent(`${shareData.text} ${shareData.url}`)}`, '_blank')
        break
      default:
        if (navigator.share) {
          navigator.share(shareData).catch((error) => console.log('Error sharing:', error))
        } else {
          alert('Sharing is not supported on this browser')
        }
    }
  }

  const downloadQRCode = () => {
    if (qrRef.current) {
      const svg = qrRef.current;
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      const img = new Image();
      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx?.drawImage(img, 0, 0);
        
        // Instead of adding the logo here, we'll use the QR code with the logo already embedded
        const pngFile = canvas.toDataURL("image/png");
        const downloadLink = document.createElement("a");
        downloadLink.download = "panyero-qr-code.png";
        downloadLink.href = pngFile;
        downloadLink.click();
      };
      img.src = `data:image/svg+xml;base64,${btoa(svgData)}`;
    }
  };

  return (
    <Card className="flex justify-center items-center">
      <CardContent className="flex flex-col items-center space-y-6 py-6">
        <Button onClick={toggleQRCode}>
          {showQR ? 'Hide QR Code' : 'Show QR Code'}
        </Button>
        {showQR && (
          <div className="bg-white p-4 rounded-lg">
            <QRCodeSVG 
              value={`panyero://pay/${accountNumber}`} 
              size={200}
              level="H"
              imageSettings={{
                src: "https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/exchange-crypto-app-template-u-i-kit-mj3gm6/assets/oukz3uoshich/panyero.png",
                x: undefined,
                y: undefined,
                height: 40,
                width: 40,
                excavate: true,
              }}
              ref={qrRef}
            />
          </div>
        )}
        {showQR && (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="flex items-center">
                  <Share2 className="mr-2 h-4 w-4" />
                  Share QR Code
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => shareQRCode('messenger')}>
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Messenger
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => shareQRCode('whatsapp')}>
                  <Phone className="mr-2 h-4 w-4" />
                  WhatsApp
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => shareQRCode('email')}>
                  <Mail className="mr-2 h-4 w-4" />
                  Email
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => shareQRCode('other')}>
                  <Share2 className="mr-2 h-4 w-4" />
                  Other
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button onClick={downloadQRCode} className="flex items-center">
              <Download className="mr-2 h-4 w-4" />
              Download QR Code
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  )
}

