export interface User {
  accountNumber: string;
  name: string;
  isActive: boolean;
}

export const mockUserDirectory: User[] = [
  { accountNumber: "1234567890", name: "John Doe", isActive: true },
  { accountNumber: "0987654321", name: "Jane Smith", isActive: true },
  { accountNumber: "1111222233", name: "Bob Johnson", isActive: false },
  { accountNumber: "4444555566", name: "Alice Brown", isActive: true },
];

export function isActiveAccount(accountNumber: string): boolean {
  const user = mockUserDirectory.find(user => user.accountNumber === accountNumber);
  return user ? user.isActive : false;
}

export function getUserByAccountNumber(accountNumber: string): User | undefined {
  return mockUserDirectory.find(user => user.accountNumber === accountNumber);
}

