export interface DrawResult {
  gameId: string;
  gameName: string;
  drawDate: string;
  drawTime: string;
  numbers: number[];
}

export interface NextDraw {
  gameId: string;
  gameName: string;
  drawDate: string;
  drawTime: string;
}

const mockResults: DrawResult[] = [
  { gameId: '649', gameName: '6/49 Super Lotto', drawDate: '2024-12-08', drawTime: '11:00 AM', numbers: [9, 12, 17, 23, 34, 45] },
  { gameId: '642', gameName: '6/42 Lotto', drawDate: '2024-12-08', drawTime: '09:00 AM', numbers: [3, 11, 18, 24, 37, 42] },
  { gameId: '645', gameName: '6/45 Mega Lotto', drawDate: '2024-12-07', drawTime: '04:00 PM', numbers: [5, 16, 22, 31, 39, 44] },
];

const mockNextDraws: NextDraw[] = [
  { gameId: '649', gameName: '6/49 Super Lotto', drawDate: '2024-12-08', drawTime: '04:00 PM' },
  { gameId: '642', gameName: '6/42 Lotto', drawDate: '2024-12-08', drawTime: '02:00 PM' },
  { gameId: '645', gameName: '6/45 Mega Lotto', drawDate: '2024-12-08', drawTime: '06:00 PM' },
];

export function getLatestDrawResult(): DrawResult {
  return mockResults[0];
}

export function getNextDraw(): NextDraw {
  return mockNextDraws[0];
}

export function getDrawHistory(): DrawResult[] {
  return mockResults;
}

